import React, { Component } from "react";

export default class Assignments extends Component {
  render() {
    return (
      <div
        className="container , card"
        style={{
          width: "30%",
          textAlign: "center",
          backgroundColor: "lightyellow",
          color: "darkgreen",
        }}
      >
        <h4>Coming Soon ...</h4>
      </div>
    );
  }
}
