import React, { Component } from "react";
import { Link } from "react-router-dom";

class MyNavbarTeacher extends Component {
  constructor(props) {
    super(props);
    this.state = {
      sflag: 1,
      cflag: 1,
    };
  }

  checkSubject = (event) => {
    if (event.target.value === "Select Subject") {
      this.setState({ sflag: 1 });
      localStorage.removeItem("module");
      // const xx = document.createElement("a");
      // xx.href = "/dashboard";
      // xx.click();
    } else {
      this.setState({ sflag: 0 });
      localStorage.setItem("module", event.target.value);
    }
  };

  checkCourse = (event) => {
    if (event.target.value === "Select Course") {
      this.setState({ cflag: 1, sflag: 1 });
      document.getElementById("s").value = "Select Subject";
      localStorage.removeItem("course");

      const xx = document.createElement("a");
      xx.href = "/dashboard";
      xx.click();
    } else {
      this.setState({ cflag: 0 });
      localStorage.setItem("course", event.target.value);
      localStorage.setItem("module", "Select Subject");
      document.getElementById("s").value = "Select Subject";

      if (localStorage.getItem("course") === "DAC") {
        document.getElementById("s1").innerHTML = "Core Java";
        document.getElementById("s2").innerHTML = "Advance Java";
        document.getElementById("s3").innerHTML = "Database";
      } else if (localStorage.getItem("course") === "DBDA") {
        document.getElementById("s1").innerHTML = "Python";
        document.getElementById("s2").innerHTML = "Big Data";
        document.getElementById("s3").innerHTML = "Maching Learning";
      } else {
        document.getElementById("s1").innerHTML = "Artificial Intelligence";
        document.getElementById("s2").innerHTML = "Neural Networks";
        document.getElementById("s3").innerHTML = "Data Analytics";
      }
    }
    // document.getElementById("s").value = "Select Subject";
  };

  render() {
    return (
      <div>
        <div className="btn-group btn-block" role="group" aria-label="">
          <Link
            className="btn btn-secondary"
            to="/"
            style={{ borderRadius: "0px" }}
          >
            Back
          </Link>
          <Link
            className="btn btn-warning"
            to="/dashboard/publicnotification"
            style={{ borderRadius: "0px" }}
          >
            Public Notifications
          </Link>

          <Link to="#">
            <select
              className="btn btn-warning"
              style={{ borderRadius: "0px" }}
              id="c"
              onChange={this.checkCourse}
            >
              <option defaultValue>Select Course</option>
              <option>DAC</option>
              <option>DBDA</option>
              <option>AI</option>
            </select>
          </Link>

          <Link to="/dashboard/viewstudents">
            <button
              style={{ borderRadius: "0px" }}
              className="btn btn-warning"
              disabled={this.state.cflag === 1 ? true : false}
              onClick={this.viewStudents}
            >
              View Students
            </button>
          </Link>
          <Link to="/dashboard/coursenotifications">
            <button
              style={{ borderRadius: "0px" }}
              className="btn btn-warning"
              disabled={this.state.cflag === 1 ? true : false}
            >
              Course Notifications
            </button>
          </Link>
          <Link to="/dashboard/coursematerial">
            <button
              style={{ borderRadius: "0px" }}
              className="btn btn-warning"
              disabled={this.state.cflag === 1 ? true : false}
            >
              Course Material
            </button>
          </Link>
          <Link to="#">
            <select
              style={{ borderRadius: "0px" }}
              className="btn btn-warning"
              id="s"
              disabled={this.state.cflag === 1 ? true : false}
              onChange={this.checkSubject}
            >
              <option defaultValue>Select Subject</option>
              <option id="s1">Core Java</option>
              <option id="s2">Adv JAva</option>
              <option id="s3">Database</option>
            </select>
          </Link>
          <Link to="/dashboard/replyqueries">
            <button
              style={{ borderRadius: "0px" }}
              className="btn btn-warning"
              disabled={this.state.sflag === 1 ? true : false}
            >
              Queries
            </button>
          </Link>
          <Link to="/dashboard/assignments">
            <button
              style={{ borderRadius: "0px" }}
              className="btn btn-warning"
              disabled={this.state.sflag === 1 ? true : false}
            >
              Assignments
            </button>
          </Link>
        </div>
      </div>
    );
  }
}

export default MyNavbarTeacher;
