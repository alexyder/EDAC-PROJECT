import React, { Component } from "react";
import One from "../components/anshul/poc/One";

export default class Test extends Component {
  render() {
    return (
      <div>
        <One />
        Hello testing at work
      </div>
    );
  }
}
