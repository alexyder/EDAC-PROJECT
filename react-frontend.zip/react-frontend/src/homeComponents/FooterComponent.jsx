import React, { Component } from "react";

class FooterComponent extends Component {
  constructor(props) {
    super(props);

    this.state = {};
  }

  render() {
    return (
      <div>
        <footer className="footer">
          <span>
            CDAC , Bangalore , Phone - 080661 16400
            <br />
            No.1, Swami Vivekananda Rd, Sadanandanagar, Byappanahalli,
            Bengaluru, Karnataka 560038
            <br />© 2021 C-DAC. All rights reserved
          </span>
        </footer>
      </div>
    );
  }
}

export default FooterComponent;
