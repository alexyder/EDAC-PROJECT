import React, { Component } from "react";
import Sprint1 from "../../../services/Sprint1";

class PubNoti extends Component {
  constructor(props) {
    super(props);
    this.state = {
      text: "",
      status: "",
    };
  }
  sendNotification = (e) => {
    if (this.state.text !== "") {
      Sprint1.setPublicNotifications(this.state.text)
        .then((res) => {
          if (res.status === 200) {
            this.setState({ status: "Notification Sent" });
          }
        })
        .catch(() => {
          this.setState({ status: "Server Error" });
        });
    } else {
      this.setState({ status: "Cannot Send Empty Data" });
    }

    // initializing
    document.getElementById("xyz").value = "";
    this.setState({ text: "" });
  };

  changeHandler = (e) => {
    this.setState({ text: e.target.value });
    this.setState({ status: "" });
  };

  clearing = () => {
    document.getElementById("xyz").value = "";
    this.setState({ text: "" });
  };
  render() {
    return (
      <div>
        <hr />
        You can Add Public notifications from here
        <hr />
        <div className="container">
          <b>
            <label>Enter Public Notification</label>
          </b>
          <br />
          <textarea
            style={{
              resize: "both",
              backgroundColor: "oldlace",
              borderRadius: "5px",
            }}
            id="xyz"
            rows="4"
            cols="100"
            onChange={this.changeHandler}
            placeholder="These notifications can be viewed from home page"
          ></textarea>
          <div className="btn-group btn-block" role="group" aria-label="">
            <div>
              <button
                style={{
                  borderTopRightRadius: "0px",
                  borderBottomRightRadius: "0px",
                }}
                className=" btn btn-success"
                onClick={this.sendNotification}
              >
                Send
              </button>
              <button
                className="btn btn-warning"
                style={{
                  borderTopLeftRadius: "0px",
                  borderBottomLeftRadius: "0px",
                }}
                onClick={this.clearing}
              >
                Clear
              </button>
              <hr />
            </div>
          </div>
          <div>{this.state.status}</div>
          <div>
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
          </div>
        </div>
      </div>
    );
  }
}

export default PubNoti;
