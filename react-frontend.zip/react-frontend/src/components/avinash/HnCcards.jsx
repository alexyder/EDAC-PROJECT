import React from "react";

function HnCcards(props) {
  return (
    <div className="card">
      <img src={props.img} alt="Avatar" style={{ width: "100%" }}></img>
      <div className="container">
        <h5>
          <b>
            {props.clg}
            <hr />
          </b>
        </h5>
        <h5> Hostel : {props.hostel}</h5>
        <ul>
          <li>Info - {props.Aminities}</li>
          <li>Fees - {props.hFees}</li>
          <li>Address - {props.Location}</li>
        </ul>
        <h5>Mess : {props.Mess}</h5>
        <ul>
          <li>Time -{props.Time}</li>
          <li> Fees - {props.mFees}</li>
        </ul>
      </div>
    </div>
  );
}

export default HnCcards;
