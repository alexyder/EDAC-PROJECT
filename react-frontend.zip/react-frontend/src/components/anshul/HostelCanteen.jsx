import React, { Component } from "react";
import { Link } from "react-router-dom";

export default class HostelCanteen extends Component {
  render() {
    return (
      <div
        className="card"
        style={{
          width: "100%",
        }}
      >
        <Link
          to="/hostelandcanteen"
          className=" btn btn-light"
          style={{
            marginBottom: "0%",
            color: "black",
            padding: "25px",
          }}
        >
          <div>Hostel And Canteen Information</div>
        </Link>
      </div>
    );
  }
}
