import React from "react";
import { Link } from "react-router-dom";
import "./Arun.css";

const achive = (
  <div>
    <ul>
      <Link to="/onee">
        <li>High Performance Computing, Grid & Cloud Computing</li>
      </Link>
      <br />
      <Link to="/Two">
        <li>Multilingual Conputing & Heritage Computing</li>
      </Link>
      <br />
      <Link to="/Three">
        <li>Professional Electronics, VLSI & Embedded Systems</li>
      </Link>
      <br />
      <Link to="/Four">
        <li>Software Technologies including FOSS</li>
      </Link>
      <br />
      <Link to="/Five">
        <li>Cyber Security & Cyber Forensics</li>
      </Link>
      <br />
      <Link to="/Six">
        <li>Health Informatics</li>
      </Link>
      <br />
      <Link to="/Seven">
        <li>Education & Training</li>
      </Link>
    </ul>
  </div>
);

function Achivements() {
  return achive;
}

function Two() {
  return (
    <div>
      {" "}
      <p>
        <h1>Machine Translation</h1>
        Mantra-Rajya Sabha MANTRA-Rajya Sabha Translation system translates
        English documents to Hindi pertaining to Parliamentary domain (Upper
        House of Parliament of India). List of Business [LOB], Papers to be Laid
        on the Table [PLOT], Bulletin Part-I are migrated to Unicode version and
        deployed at Rajya Sabha Secretariat which is being used for their daily
        proceedings. At present, Bulletin Part-II is being developed. During the
        year 126 files were created using the system and synopsis document were
        prepared using Mantra-Rajya Sabha system for four sessions. C-DAC setup
        a centralized supercomputing facility titled PARAM-Ishaan with peak
        computing power of 240 Tera Flops with 300TB storage at IIT, Guwahati
        under the NE funding scheme of MeitY. Presently 400 users from IITG are
        extensively using this system for their research. C-DAC conducted two
        workshops and trained around 150 faculties and research scholars from
        IITG in the area of HPC.
        <img src="https://www.cdac.in/index.aspx?id=img_achievements&dynamicId=rajya_sabha.jpg"></img>
        <h2>
          Indian Language to English Machine Translation System (IL-EMT) for
          Judicial domain
        </h2>
        C-DAC in collaboration with IIT Delhi, IIT Patna, IIIT Allahabad, IIT
        Bombay, IIIT Hyderabad is developing a Webbased hybrid MT system for
        Hindi to English. During the year various activities were carried out
        including fine tuning / adaptation of various tools, lexical resources
        and engines such as Input Format Extractor, Parallel corpora,
        Morphological analyser (MA), Part of Speech tagger (PoS), Named Entity
        Recognizer (NER), dependency parser, Word Sense Disambiguation (WSD),
        Post Processing Tools and Linguistic Resource Management Tools.
        AnglaKokBorok: English-KokBorok Machine Aided Translation (MAT) System
        AnglaBharati (English to Indian Language Machine Translation System):
        The AnglaBharati Machine Translation system has been adapted for
        generating translation from English into eight Indian languages viz.
        Assamese, Bangla, Hindi, Malayalam, Nepali, Punjabi, Telugu and Urdu.
        The Systems are deployed on Meghraj Cloud for Hindi, Urdu, Punjabi,
        Bangla, Nepali, Malayalam and Telugu languages. During the year
        AnglaKokBorak: English-KokBorok Machine Aided Translation (MAT) System
        has been specifically designed for translating English to KokBorok
        language, based on Anglabharati technology. It analyses English only
        once and creates an intermediate structure with most of the
        disambiguation performed. In AnglaKokBorok, this intermediate structure
        is then converted to KokBorok language through a process of
        text-generation. A translation workbench has been developed that
        collects user's feedback through crowd sourcing.
      </p>
    </div>
  );
}

function onee() {
  return (
    <div>
      <p>
        <h2>National Supercomputing Mission</h2>
        <img src="https://www.cdac.in/index.aspx?id=img_achievements&dynamicId=ishan_lrg.jpg"></img>
        <hr />
        Cabinet Committee on Economic Affairs (CCEA) approved the project titled
        “National Supercomputing Mission (NSM) : Building Capacity and
        Capability" on April 9, 2015 to be implemented jointly by the Ministry
        of Electronics and Information Technology (MeitY) and Department of
        Science and Technology (DST) with Indian Institute of Science, Bangalore
        and C-DAC being the executing agencies. The National Supercomputing
        Mission envisages harmonizing the efforts of stakeholders involved in
        R&D efforts in HPC through nationwide centralized coordination. C-DAC is
        entrusted with building systems indigenously. NSM is divided in four
        verticals: Facilities and Infrastructure, Applications, Human Resource
        Development and Research and Development. C-DAC has prepared the (Build
        Approach) RFP for Phase-I and Phase-II. Phase-1 includes build and
        deploy of 3 systems at IIT Kharagpur (1.3 PetaFlops), at IIT BHU,
        Varanasi (650 TeraFlops) and IISER Pune (650 TeraFlops). In phase-2,
        multiple HPC systems with cumulative compute power of 10 PetaFlops is
        planned. An HPC lab is setup with compute power of about 150TF for HPC
        System design, development and integration. For NSM human resource
        development, short-term, medium-term and formal-education programs were
        conducted.
      </p>
    </div>
  );
}

function Three() {
  return (
    <div>
      <p>
        <h1>
          {" "}
          C-DAC has demonstrated its expertise over the years in developing
          sophisticated, compact and cost effective electronic systems
        </h1>{" "}
        for defense, law enforcement agencies, industrial purposes and social
        empowerment. Primary areas of focus under Professional Electronics
        include smart system solutions, security & surveillance, power
        electronics, strategic electronics, and intelligent traffic systems. R&D
        in Electronics Educational Boards C-DAC has developed low cost
        educational boards to cater to the need of laboratory requirement of the
        institutions in Digital Electronics, Embedded System Design and Digital
        Signal Processing domains. These boards are - Field Programmable Gate
        Array (FPGA) board, Embedded System Design (ESD) board and Digital
        Signal Processing (DSP) board respectively. All the boards are supported
        by the e-learning content provided by C-DAC at link
        https://esdt.dcservices.in
        <img src="https://www.cdac.in/index.aspx?id=img_achievements&dynamicId=presys.jpg"></img>
        <hr />
        Electronic personal safety device (eSafeT) : It is used to track the
        thermal history of the items (Vaccine, Blood bags, Medicines, Perishable
        goods, and other temperature sensitive items) while in storage or in
        transit. This eSafeT product can be used in Blood Banks, Pharmaceutical
        Stores, Warehouses, Cold Chain and Frozen Food Management. Vehicle
        Control Unit (VCU) and Train Communication Network The technology for
        Vehicle Control Unit (VCU) and Train Communication Network has been
        transferred to four industries. There are around 600 Electric Locos with
        Indian Railways which may need this technology to keep them in
        operation. Train Train Ultrasonic High Precision Diameter Measurement
        System (PreSys) It is developed for Babha Atomic Research Center (BARC),
        is used to measure the diameter of pipe structures with high precision
        better than 10µm (in water). The system finds application in measuring
        precisely the diameter of heat-resistant composite alloy pipes employed
        in nuclear power plants. The technology used in the system can be reused
        for a wide variety of high precision distance measurement applications
        and has huge ToT potential. System has been deployed at BARC, Mumbai.
        Presys Wireless Traffic Control System (WiTraC) Different Intelligent
        Transportation Systems products like Wireless Traffic Control System
        (WiTraC),Traffic Monitoring and Management Software (TraMM), Red Light
        Violation Detection System (iRIDS) and Adaptive Traffic Control System
        (CoSiCoSt) have been developed andare being deployed in 7 cities all
        over India. Technology is transferred to 13 agencies. witrac
        architecture Zigbee Enabled LED Luminaire (ZLED) with Occupancy based
        Control Two variants of Zigbee controlled LED Luminaire (ZLED 2'x2' and
        ZLED 4'x1') were designed and developed under the project titled
        “Development of ICT Technologies for Smart Buildings with Low Carbon
        Emission” funded by MeitY. ZLED provides different levels of dimming (5%
        to 100%) to give optimum illumination in work plane. ZLED can be
        controlled based on occupancy using zone/individual control and Hidden
        Markov Model based occupancy prediction control. Around 140 numbers of
        ZLED have been deployed at various locations such as MeitY, National
        PARAM Supercomputing Facility at Pune and C-DAC Hyderabad office. ZLED
        solution deployed at various places shows energy savings of 50 - 60%
        (measured value in room for a month based on the occupancy state).
        Intelligent Traffic System TraMM – Traffic Signal Monitoring &
        Management software Traffic Signal Monitoring & Management (TraMM) is an
        application that enables monitoring and managing road traffic signal
        controllers remotely from a central server located at the Traffic
        Management Centre (TMC). TraMM is integrated with C-DAC’s other
        Intelligent Transporation System (ITS) solutions like Wireless Traffic
        Control System (WiTraC) and Urban Traffic Control system (UTCS)
        controllers. It provides visualization for real time monitoring of
        signal coordination between traffic junctions using Time Space Diagram.
        Tramm CUTE – CDAC Urban Traffic Control Equipment C-DAC Urban Traffic
        Control Equipment (CUTE) is a Vehicle Actuated Adaptive Traffic Control
        System (ATCS) compatible traffic signal controller. It can take input
        from any type of vehicle detectors (inductive loop, camera, microwave
        radar etc.) and can operate on grid power, Solar Power or hybrid power.
        CUTE has a very small formfactor for pole mounting and can be monitored
        from a remote location over fiber or Managed Leased Line Network (MLLN).
        CUTE can be used as a retrofit at already signalized junctions by
        replacing the existing Pre-timed traffic signal controller. WiTrac –
        Wireless Traffic Controller The Wireless Traffic signal Controller
        (WiTraC) is used for controlling the Road Traffic Signal without a
        physical connection between the Traffic Controller equipment and the
        signal lamps. In WiTraC, the signal switching is done over air using
        2.4GHz license free ISM band. WiTraC is a Vehicle Actuated (VA) traffic
        signal controller in which the signal timings are generated based on the
        real time demand and is compatible for Adaptive traffic signaling.
        Adaptive Traffic Control System Composite Signal Control Strategy–WiTrac
        (CoSiCoSt-W) is an Adaptive Traffic Control System software compatible
        with Wireless Traffic Control System (WiTraC). CoSiCoSt is designed to
        address the highly heterogeneous traffic conditions by continuously
        assessing real-time traffic demand from vehicle detectors deployed at
        strategic locations. Based on the assessment, the system generates
        optimum signal timings for signal coordination in vehicle actuated mode
        of traffic signal operation, thereby minimizing stops and delay at
        traffic junctions and reduce overall journey time. The Transfer of
        Technology (ToT) of the above solution was carried to the same five
        industry partners as that of TraMM. C-DAC is also implementing ATCS for
        traffic signaling at 43 junctions and 10 midblock pedestrian crossings
        in Bus Rapid Transit System (BRTS) between Hubli and Dharwad (22.25km)
        in the state of Karnataka using C-DAC Urban Traffic signal controllers
        (CUTE) and Composite Signal Control Strategy (CoSiCoSt) software. This
        shall reduce stop delay at intersections and midblock pedestrian
        corssings leading to decreased travel time between the twin cities.
        iRIDS – Red Light Violation Detection System C-DAC has developed Red
        Light Violation Detection System (iRIDS) that provides solution to
        automatic identification of red light violations at signalized traffic
        junctions. It automatically captures and presents evidence of the red
        light violation that helps smooth functioning of law enforcement. It is
        devised in such a way that it is compatible with any traffic signal
        controller and can operate during low light condition and night
        operation using Infra-Red sensors. During the year, Transfer of
        Technology (ToT) of the above solution was carried to industry partner
        M/s. Onnyx Electronics, New Delhi. Safety Enhancement and Priority at
        Traffic Junctions Solution for Pedestrian Safety Enhancement and
        Emergency Service Vehicle Priority System at Signalized Traffic
        Junctions have been developed. The pedestrian safety enhancement system
        enables safe crossing of differentlyabled pedestrians at motorways by
        enhancing the crossing time through assessment of the level of
        disability of the pedestrians. The emergency service vehicle priority
        system provides priority green at signalized traffic junction for
        emergency service vehicle using Vehicle to Infrastructure (V2I)
        communication.
      </p>
    </div>
  );
}
function Four() {
  return (
    <div>
      {" "}
      <h1> e-Governance</h1>
      Roll out of National e-Services of Election Commission of India
      (http://nvsp.in) - (ECI) Roll out of National e-Services of Election
      Commission of India envisages e-delivery of services of Election
      Commission of India (ECI) to the citizens of India through optimum use of
      ICT with an objective to bring all these services under single umbrella
      and provide a platform for offering various services to citizens and
      Election Commission officials. C-DAC has developed National Voters
      Services Portal (NVSP) to assist voters and provide information related to
      elections, polling booths and electoral rolls. Highlights of this
      initiative include search based on demographic details and EPIC number,
      facility of online application for inclusion, modification and deletion in
      E-Roll in 14 Indian languages with keyboards and auto transliteration
      support, tracking status of application, facility to know BLO/ ERO/ DEO/
      CEO and Constituency/ Part, submitting family details, absent, shifted and
      dead elector details, linking of Aadhaar number with EPIC number, services
      for ECI officials, synchronizations services between national and state
      databases, digital repository and knowledge management, mobile
      applications for citizens and ERONET mobile application for booth level
      officers. The ERO-NET is now operational in 32 States / UT and others will
      soon follow. As of now a total of 1.35 billion hits are there on the
      http://nvsp.in. e-Pramaan: A National e-Authentication Service e-Pramaan
      is a uniform standard based national e-authentication service developed by
      C-DAC to authenticate users of various Government services in a safe and
      secure manner for accessing services through desktop as well as mobile.
      This framework facilitates expeditious onboarding of any Government
      department or agency in the country for the purpose of standard based
      e-Authentication without having to create its own infrastructure. It
      offers secure authentication with various levels of assurances by
      verifying the credentials of e-Pramaan users accessing different
      Government services through internet or mobile devices. It provides
      various authentication mechanisms such as password based authentication,
      OTP based authentication, digital certificate based authentication and
      biometric (fingerprint) based authentication. 173 departments have been
      integrated across Central and State departments as well as Public and
      Private sector services. 6.7+ Crore transactions have been completed
      during this period.
      <br />
      <img src="https://www.cdac.in/index.aspx?id=img_achievements&dynamicId=e_pramaan.jpg"></img>
      <hr />
      <h3>Pramaan</h3>
      e-Pramaan - A National e-Authentication Service eSangam: e-Governance
      Services Integration Framework eSangam is a Service Oriented Architecture
      (SOA) based constellation of National and State eGovernance Service
      Delivery Gateways. eSangam (NSDG), a Mission Mode Project under NeGP has
      gone live in August, 2008 and is currently in its second phase that
      started on July 7, 2015 for five year duration. eSangam, being a
      middleware, facilitates service integration and message exchange between
      integrated departments. C-DAC being the implementation agency is also the
      Gateway Service Provider for Meity, Govt. of India. Functional and
      Infrastructure enhancement of eSangam National Gateway was successfully
      completed and 513 services have been registered in the production
      environment of eSangam during this period. Total transactions through
      eSangam during this period are 5.47 Crores.
      <br />
      <img src="https://www.cdac.in/index.aspx?id=img_achievements&dynamicId=e_sangam.jpg"></img>
      <hr />
      <h3> eSangam</h3>
      eSangam Architecture Mobile Seva: A National Mobile Governance Platform
      Mobile Seva is a national mobile governance platform that facilitates
      delivery of public services over mobile devices using mobile based
      channels such as SMS, USSD, IVRS and m-Apps. SMS, USSD and IVRS based
      services are accessible to citizens through very basic phones. Mobile Seva
      platform provides a Government App Store which hosts a number of mobile
      applications developed for various Government departments. The App Store
      supports hosting of applications for multiple mobile platforms (e.g.
      Android, JavaME, etc.). Government departments can develop and deploy
      mobile applications for providing their services through mobile devices.
      Around 3,882 Government departments and agencies integrated with the
      Mobile Seva platform. Approximately 2100 Cr SMSes have been pushed so far
      by integrating Departments. eRA: e-Governance Application Integration with
      Reconfigurable Architecture Middleware is a key ingredient of distributed
      computing. As e-Governance systems evolve, they need to provide advanced
      features to support dynamic and flexible processes that adapt as business
      situations change as well as integrate with other systems which have
      functional/data overlaps and they need to provide complete control and
      visibility into the entire e-Governance scenario. These features
      ultimately require a flexible, distributed architecture that enable secure
      collaboration, advanced data management, dynamic system updates, and
      custom rule-based processes. Identifying these needs of the modern
      e-Governance systems, C-DAC developed eRA (e-Governance Application
      Integration with Reconfigurable Architecture). eRA defines a
      reconfigurable middleware with support for workflow and rule-based service
      configurations. eRA MTRANS – Mobile Transaction Framework Mobile
      applications run in an environment characterized by frequent network
      disconnections, low bandwidth, mobility related issues, low computing
      power and limited set of APIs for application development. Mobile
      transactions can face frequent aborts due to frequent disconnections from
      the server and result in low transaction throughput. MTRANS framework has
      been developed to provide JAVA based API libraries on Android and J2ME
      platforms for developing transactional network based applications with
      less effort and help achieve better transaction throughput. Its key
      features are: It supports disconnected operation of applications and helps
      achieve better transaction throughput It adapts the MVC (Model View
      Controller) design approach innovatively to suit mobile applications
      processing It provides a unique Message Exchange Protocol over HTTP and
      API for handling business data It works independent of any mobile database
      and provides its own data access APIs Unified Portal for EPFO C-DAC has
      developed a unified portal for Employees' Provident Fund Organization
      (EPFO). The portal facilitates Online Registration of Establishment
      (OLRE), Universal Account Number Allocation, Electronic Challan cum
      Remittances, integration with five nationalized banks, integration with
      Unique Identification Authority of India (UIDAI) for demographic AADHAAR
      authentication for registering member KYC, integration with Income Tax
      Portal for PAN verification services and integration with e-Biz, e-Nivesh
      and Shram Suvidha Portal. The portal is handling transactions amounting to
      approximately Rs. 10,000 crore remittances per month paid by approximately
      6 lakh establishments for around 40 million active members. Pradhan Mantri
      Rojgar Prothsahan Yojana (PMRPY) for EPFO C-DAC has developed a solution
      for Pradhan Mantri Rojgar Prothsahan Yojana (PMRPY) for EPFO so that the
      establishment covered under the EPF act which logs into the unified portal
      using the custom credentials generated at the unified portal itself can
      login to the PMRPY portal using the PF code allotted to the establishment
      or Labour Identification Number (LIN) allotted by Shram Suvidha Portal.
      The solution facilitates Aadhaar verification with UIDAI, comprehensive
      MIS to monitor the scheme statistics and integration with Indian Bank for
      reimbursement of the benefits passed on to the establishment to EPFO
      account. Electronically Transmitted Postal Ballot System (ETPBS) C-DAC in
      collaboration with Election Commission of India developed Electronically
      Transmitted Postal Ballot System (ETPBS) for the use of service voters. It
      is a fully secured system that enables entitled service voters to cast
      their vote using electronically received postal ballots from anywhere
      outside their constituency. Electors/Service voters eligible for
      Electronically Transmitted Postal Ballot may make a choice of casting
      their vote through this system. The voter who makes such a choice will be
      entitled for Electronically Transmitted Postal Ballot for a particular
      election. Postal Ballots for entitled voters will be uniform across all
      categories. It will be delivered in electronic data format to the entitled
      voter on a real-time basis. Pilot and trial implementation of this system
      was carried out in UP, Punjab, Uttarakhand, Goa and Manipur state general
      elections (http://etpbs.in). Meri Sadak – Citizen Feedback System With an
      objective to enable citizens to register their complaints regarding
      Pradhan Mantri Gram Sadak Yojana (PMGSY) roads, "Meri Sadak" mobile app
      was developed by C-DAC. The same was launched by Ministry of Rural
      Development on July 20, 2015 and made available for free download from
      Google Play Store. The mobile app enables citizens to provide feedback
      with the photographs from the site to National Rural Roads Development
      Agency (NRRDA). NRRDA after verification forwards the feedback to the
      concerned State Quality Coordinators (SQCs) of the Nodal Department
      implementing PMGSY who responds to the feedback posted by the citizen.
      Citizen can also monitor the redressal of his / her feedback through this
      app. System for Central Drugs Standard Control Organization (SUGAM) C-DAC
      has developed SUGAM, a web-based system for Central Drugs Standard Control
      Organization (CDSCO), to facilitate complete life-cycle of user
      application starting from application submission to CDSCO till grant of
      licenses and approvals from CDSCO. Its key features include Real Time
      Tracking of status of applications, Analytical Dashboard and Responsive
      UI, Data Mining, Statistical Analysis, Report Generation and Alerts and
      Notifications. SUGAM portal was launched by Hon’ble Union Minister of
      Health and Family Affair, Shri J. P. Nadda on November 14, 2015 at Indian
      Pharmacopoeia Commission (IPC), Ghaziabad, Uttar Pradesh.
      Operationalization of various processes including Grant of approval to
      conduct clinical trials for drugs & vaccines in India, grant of
      permission, to manufacture/import new drugs In India, generation of
      comprehensive database for drug manufacturing sites and drug formulations
      in India, generation of comprehensive database for drug wholesalers and
      retailers in India and process automation for drug sample testing and
      generation of reports and comprehensive database for drugs/ vaccines was
      carried out. e-Hastakshar – C-DAC's eSign Service C-DAC has developed
      e-Hastakshar – C-DAC's eSign Service that facilitates instant signing of
      documents online by citizens in a legally acceptable form. Using this, an
      Aadhaar holder with registered mobile number with Aadhaar can
      electronically sign a form/document anytime, anywhere, using any device.
      Through e-Hastakshar, C-DAC offers hassle-free fully paperless citizen
      services and convenience to users. C-DAC utilizes service of Unique
      Identification Authority of India (UIDAI) for on-line authentication and
      Aadhaar eKYC service. C-DAC carried out integration with various
      Government and private agencies for leveraging eSign service at production
      level. Nearly 27 lakh signatures have been offered for various agencies.
      National Imports Database v2 (NIDB2) NIDB2 is an assessment tool and a
      decision support system for customs officers. It is used for assessment of
      imported goods at the numerous custom stations in India. NIDB2 provides
      instant information to compare declared values with contemporaneous import
      prices as well as current international prices of identical and similar
      goods. This enables them to take well-informed decisions on valuation and
      classification of imported goods and to prevent loss of revenue on account
      of under valuation or miss-declaration. It has been deployed at
      Directorate General of Valuation, India. Kenya Revenues Authority
      Valuation System (KRAVS) - Phase 2 KRAVS is an assessment tool and
      decision support system for custom officers of Kenya Revenue Authority
      (KRA), Kenya. It is enriched with various features such as up-to-date
      price reference database on accepted transaction values, valuation based
      risk management system, statistical and analytical reports and graphical
      reports and facility to upload international prices for easy reference
      etc. During the year, pilot deployment was carried out and hands-on
      training sessions were provided to KRA ICT officials on KRAVS2 application
      at Nairobi, Kenya. e-Mulazim e-Mulazim is a web based open source Human
      Resource management software for small and medium enterprises. This user
      friendly system automates the complete employee scheduling process and
      allows the user to maintain employee attendance records, leaves, payroll,
      inventory, CMS, Forums, and claim details electronically and helps to
      reduce overall management costs and time. C-DAC deployed the solution at
      National Agro Biotech Institute (NABI), Mohali and Center of Innovative
      and Applied Bio Research (CIAB), Mohali, Translational Health Science and
      Technology Institute (THSTI), Gurgaon, Haryana State Electronics
      Development Corporation Limited (HARTRON), Chandigarh and National
      Institute of Technical Teachers Training and Research (NITTTR),
      Chandigarh. Rajasthan Works Online Monitoring System Public Works
      Department (PWD), Government of Rajasthan is executing the construction of
      road works under the scheme “Rajasthan Road Sector Modernization Projects”
      (RRSMP). The software application captures the details of the contractors,
      proposal details and sanction by the department at the state level,
      agreement details, and physical and financial progress details. Electronic
      Project Proposal Management System (e-PPMS) C-DAC has developed a solution
      called electronic Project Proposal Management System (ePPMS) to manage the
      life cycle of funded research projects, enable researchers to make online
      submission of proposals, technical evaluation of proposals, financial
      approvals and tracking of status of proposals etc. C-DAC deployed the same
      for Indian Council of Medical Research and Department of Health Research.
      Four major schemes/programs of Science and Engineering Research Board
      (SERB) including Ayurvedic Biology Program, J. C. BOSE Fellowship,
      Financial Assistance to Professional Bodies and Seminar/Symposia and
      Empowerment and Equity Opportunities for Excellence in Science were
      launched in the online system. Works and Accounts Management Information
      System (WAMIS) WAMIS – Works and Accounts Management Information System is
      a comprehensive solution designed and developed by C-DAC to encompass the
      entire lifecycle of a typical construction project work right from its
      inception to its final completion. This system is being implemented in 6
      departments of Jharkhand State including Department of Water Resources,
      Drinking Water Supply, Rural Works, Forest, Road Construction and Building
      Construction covering over 400 divisional offices. This was formally
      launched at the hands of the Shri Raghubar Das, Hon'ble CM of Jharkhand on
      February 11, 2017. WAMIS is also being implemented in the State of Odisha,
      Maharashtra and Tripura. IT Enabled Operation, Maintenance & Awareness of
      Semiconductor Integrated Circuits Layout Design Registry (SICLDR) C-DAC
      developed a pilot solution for SICLDR to facilitate online IC Design
      Registration and Maintenance of records as per the Semiconductor
      Integrated Circuits Layout Design Act 2000 and Rules 2001. An e-filing
      system for facilitating online filing of Design Registration applications
      and a Backend e-Processing application for processing the online filed
      applications have been developed as part of this solution. Customs
      Valuation System (CVS) Customs Valuation System (CVS) is a decision making
      and analysis tool to assist customs officers in valuing price of a
      commodity. The system has been developed by C-DAC in consultation with
      Directorate General of Valuation (DGOV), India. It has been implemented in
      Kenya, Ethiopia and India. Warehouse Management System (eSAMBHARANI) This
      software package covers the activities of a warehouse such as deposit,
      extension, reservation, and release of items and finance at warehouses,
      consolidation of the warehouse level activities and office management at
      container freight station and regional offices, MIS, payroll,
      superannuation, etc. The solution was developed for Kerala State
      Warehousing Corporation integrating its activities at 60 warehouses, 9
      regional offices, three zonal offices, one container freight station and
      the head office. Sufal Bangla Mobile app and IVR System (Agri. Price
      Information System) The system provides the latest prices of agricultural
      commodities over the telephone and has been deployed over the web for
      Sufal Bangla. Web Portal and Mobile app for Micro level Weather Forecast
      As part of the Digitally Inclusive Smart Community (DISC) project under
      the Digital India Initiative of Government of India, C-DAC has developed
      and deployed Web Portal and Mobile app for Micro level Weather Forecast in
      three languages (English, Hindi and Nagpuri).
    </div>
  );
}
function Five() {
  return (
    <div>
      <h1>End System Security</h1>
      <h2>AppSamvid</h2>
      It is application whitelisting software for Windows based PCs. This
      software is available in standalone version and helps to protect from
      threats through unknown applications / malware. All applications running
      on the system are monitored and only whitelisted items are allowed for
      execution and all other items are blocked. It can be downloaded from
      www.cdac.in/appsamvid No: of downloads: 22,536
      <br />
      <img src="https://www.cdac.in/index.aspx?id=img_achievements&dynamicId=cyber_swachhata.jpg"></img>
      <br />
      <h3>USB Pratirodh</h3>
      <img src="https://www.cdac.in/index.aspx?id=img_achievements&dynamicId=darpan_network.jpg"></img>
      <br />
      It is a software solution which controls unauthorized usage of portable
      USB mass storage devices like pen drive, external hard drives, cell
      phones, IPods, camera. USB mass storage devices are registered and binded
      to users. Only authorized users can access the registered devices.
      Solution also supports Data Encryption of USB device content, Auto run
      protection, Malware Detection using heuristic analysis and Configurable
      read / write privilege protection. This works for Windows operating
      systems.It can be downloaded from www.cdac.in/usbpratirodh .No: of
      downloads are: 34,897
      <h3>M-Kavach</h3>
      It is a comprehensive mobile device security solution for Android devices
      that addresses threats related to malware that steal personal data &
      credentials, misuse WiFi and Bluetooth resources, lost or stolen mobile
      device, spam SMSs, premium-rate SMS and unwanted / unsolicited incoming
      calls. It also provides hardening of Android platform to mitigate the
      threats that relate to data, device, applications and resource misuse.
      Major features of the hardened system include: Sandboxing of applications
      Blocking/Controlled installation of third party applications Hardware
      Resource control d) Data protection through compartmentalization. It can
      be downloaded from: www.cdac.in/mkavach . Personal edition can be
      downloaded from Google Play store.
      https://play.google.com/store/apps/details?id=org.cdac.mkavach No: of
      downloads: 2.78 Lakhs As part of Cyber Swachhta Kendra initiative of
      CERT-In, MeitY, desktop / computer security solutions, USB Pratirodh &
      AppSamvid and mobile security solution, M-Kavach were launched for free
      download to citizens by Hon’ble Minister for Electronics and Information
      Technology Shri. Ravi Shankar Prasad on February 21, 2017 at New Delhi.
    </div>
  );
}
function Six() {
  return (
    <div>
      <h1>Healthcare Solutions</h1>
      e-Aushadhi : Drug Supply Chain Management Solution C-DAC's e-Aushadhi
      solution deals with the purchase, inventory management and distribution of
      various drugs, sutures and surgical items to various District Drug
      Warehouses (DDWs), Medical Colleges, District Hospitals, Community Health
      Centres (CHCs), Primary Health Centres (PHCs) and Drug Distribution
      Centres (DDCs) from where the drugs are issued to the patients in an
      entire state, who are the final consumers in the chain.
      <h1> Achievements</h1>
      <h3>USB Pratirodh</h3>
      <img src="https://www.cdac.in/index.aspx?id=img_achievements&dynamicId=e_aushadhi.jpg"></img>
      <br />
      As per the mandate for Nation-wide rollout from the Ministry of Health and
      Family Welfare (MoHFW), Government of India (GoI), the solution is
      deployed in 16 States. Deployed Nationwide for Family Planning and TB
      programs under MoHFW C-DAC has initiated state-wide implementation in
      Uttarakhand, Bihar, Jharkhand, Uttar Pradesh and Himachal Pradesh.
      eAushadhi contributes to serve around 1-2 lakh patient in a state/day or
      even more and managing huge volumes of data with recurrent transactions
    </div>
  );
}
function Seven() {
  return (
    <div>
      <h1> Education and Training Programmes of C-DAC</h1>
      Education and Training activities at C-DAC are dedicated to create high
      quality manpower for R&D and the IT industry in general. The courses are
      offered through training centers associated with C-DAC R&D known as
      Advanced Computing Training School (ACTS) at 11 locations and network of
      15 Authorized Training Centers (ATCs) in India. C-DAC's Education and
      Training division is involved in the following activities:
      <hr />
      <ul>
        <li>Industry-specific PG Diploma programmes</li>
        <li> Industry-Academia collaborative formal education programmes</li>
        <li>Corporate training programmes</li>
        <li>Tech Sangam -Industry-academia collaborative programmes</li>
        <li>IT Skill Development programs for social sector</li>
        <li> International Initiatives</li>
        <li>
          Development and deployment of technologies for education and training
        </li>
        <li>
          Following are the major activities carried out under these categories
          during last 5 years:
        </li>
        <li> Industry-Specific PG Diploma Programmes</li>
        <li>
          Major focus of C-DAC's education and training is to generate
          industry-ready manpower in ICT areas. Towards this objective, C-DAC
          conducts the following PG Diploma programmes:
        </li>
      </ul>
      PG Diploma in Advanced Computing (PG-DAC)
      <br />
      PG Diploma in Big Data Analytics (PG-DBDA)
      <br />
      PG Diploma in Mobile Computing (PG-DMC)
      <br />
      PG Diploma in System Software Development (PG-DSSD)
      <br />
      PG Diploma in IT Infrastructure, Systems & Security (PG-DITISS)
      <br />
      PG Diploma in Geo-informatics (PG-DGi)
      <br />
      PG Diploma in Embedded Systems Design (PG-DESD)
      <br />
      PG Diploma in VLSI Design (PG-DVLSI)
      <br />
      PG Diploma in Biomedical Instrumentation & Health Informatics (PG-DBIHI)
      <br />
      During the year 2016-17, two new Post-Graduate Diploma programmes have
      been launched: Post Graduate Diploma in High Performance Computing System
      Administration (PG-DHPCSA) Post Graduate Diploma in Internet of Things
      (PG-DIoT) Achievements Every year more than 5000 students completed
      various PG Diploma programmes of C-DAC C-DAC in collaboration with
      universities, is offering advanced courses for ME/MTech. In VLSI and
      Embedded Systems Design, High Performance Computing and IT systems and
      Network Security. Corporate Training programmes C-DAC based on its
      expertise in various R&D areas offers corporate training programmes to the
      government and corporate sector. PG Degree Awarding Courses C-DAC has also
      trained over 500 students in Master Programs in collaboration with leading
      Universities such as Gujarat Technological University, Ahmadabad and
      VELTECH RR and SR University, Chennai, Manipal Univerisity, Jaipur, Sandip
      Univeristy, Nasik and Satyabama University, Chennai in advanced areas of
      ICT. M.Tech (Advanced Computing and Data Sciences) M. Tech (Embedded and
      IoT) M. Tech ECE (VLSI Design) M. Tech. (VLSI & Embedded Systems Design)
      M. Tech. (High Performance Computing) M.E.(Wireless & Mobile Computing)
      M.E.(IT System & Network Security)
    </div>
  );
}

export { Achivements, onee, Two, Three, Four, Five, Six, Seven };
export default Achivements;
