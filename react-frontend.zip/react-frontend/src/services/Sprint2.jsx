import axios from "axios";

const BASE_URL = "http://localhost:7777";

class Sp2 {
  // WORKING
  setCourseNotifications(course, data) {
    let ddd = { msg: data };
    return axios.post(
      BASE_URL + "/dashboard/coursenotifications/" + course,
      ddd
    );
  }
  // WORKING
  getCourseNotifications(prn) {
    return axios.get(BASE_URL + "/dashboard/viewcoursenotifications/" + prn);
  }

  // WORKING
  getTeacherDetails() {
    return axios.get(BASE_URL + "/dashboard/viewteacherdetails");
  }

  // WORKING
  askQuery(qobj) {
    return axios.post(BASE_URL + "/dashboard/askquery", qobj);
  }

  // WORKING
  viewQuerySt(prn) {
    return axios.get(BASE_URL + "/dashboard/viewqueryst/" + prn);
  }

  // WORKING
  viewStudents(course) {
    return axios.get(BASE_URL + "/dashboard/viewstudents/" + course);
  }
}

export default new Sp2();
