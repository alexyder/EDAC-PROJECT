import React, { Component } from "react";

export default class Two extends Component {
  render() {
    return (
      <div>
        two.jsx called
        {this.props.xx()}
      </div>
    );
  }
}
