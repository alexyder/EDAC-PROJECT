import React from 'react';
import '../../App.css';

export default function Notifications() {
  return <h1 className='notifications'>display notification</h1>;
}
