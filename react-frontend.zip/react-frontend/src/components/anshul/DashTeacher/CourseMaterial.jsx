import React, { Component } from "react";
import UploadFile from "../UploadFiles";

class CourseMaterial extends Component {
  render() {
    return (
      <div>
        Course Material will be added from here - txt , png , pdf .. etc ..
        <hr />
        <div className="container">
          <b> Course selected : {localStorage.getItem("course")}</b>
          <br />
          <br />
          <UploadFile />
        </div>
        <hr />
      </div>
    );
  }
}

export default CourseMaterial;
