import React from 'react';

export default function Queries() {
  return (
    <>
      <h1 className='queries'>upload queries</h1>
    </>
  );
}
