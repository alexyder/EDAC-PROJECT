import React, { Component } from "react";

class DacPage extends Component {
  render() {
    return (
      <div className="Mymargin" style={{ background: "rgba(0,0,0, 0.0)" }}>
        <h4 className="alert alert-secondary" style={{ textAlign: "center" }}>
          PG Diploma In Advanced Computing (PG-DAC)
        </h4>
        <hr />
        <h5>Course Focus</h5>
        <p>
          PG-DAC is the most popular PG Diploma course of C-DAC. The course is
          targeted towards engineering graduates and MCA/MSc who wish to venture
          into the domain of advanced computing. The course aims to groom the
          students to enable them to work on current technology scenarios as
          well as prepare them to keep pace with the changing face of technology
          and the requirements of the growing IT industry. The entire course
          syllabus, courseware, teaching methodology and the course delivery
          have been derived from the rich research and development background of
          C-DAC. Running successfully for 25 years, the PG-DAC course has
          produced thousands of professionals, who are well positioned in the
          industry today.
        </p>
        <br />
        <hr />

        <h5>Course Content </h5>
        <p>
          <ul>
            <li>Concepts of Programming & Operating System </li>
            <li>Object Oriented Programming with Java</li>
            <li>Algorithms and Data Structures Using Java</li>
            <li> Database Technologies</li>
            <li>Web Programming Technologies </li>
            <li>Web-based Java Programming </li>
            <li>Software Development Methodologies</li>
            <li>Effective Communication </li>
            <li>Aptitude & General English </li>
            <li>Project</li>
          </ul>
        </p>
      </div>
    );
  }
}

export default DacPage;
