import React, { Component } from "react";

class Dbda extends Component {
  render() {
    return (
      <>
      <div>
       <h1 className='dbda'>DBDA</h1>
      
         <h2>PG Diploma In Advanced Computing (PG-DBDA)</h2>
    <hr/>
    <h2>Course Focus</h2>
    <p>
        PG-DBDA will educate the aspirants who want to make an impact in the corporate and
        academic world in the domain of big data analytics as data scientist and researcher, big
        data leads/administrators/managers, business analysts and data visualization specialists.
        The course is also suitable for those who are already working in analytics to enhance their
        theoretical and conceptual knowledge as well as those with analytical aptitude and would
        like to start career in big data analytics in different business sectors. The collaboration with
        the different multi-national companies at the level of mutual research interests and
        customer related projects will ease the path for campus recruitment. The students will be
        able to work with big data platform, analyze various big data analysis techniques for useful
        business applications, design efficient algorithms for mining the data from large volumes,
        analyze the HADOOP and Map Reduce technologies associated with big data analytics,
        and explore big data applications.
    </p>
    <br/>
    <hr/>

   <h2>Course Content </h2>
    <p>
    <li>Linux Programming and Cloud Computing</li>
        <li>Python and R programming</li>
        <li>Object Oriented Programming with Java 8</li>
        <li> Advanced Analytics using Statistics</li>
        <li>Data Collection and DBMS (Principles, Tools & Platforms) </li>
        <li>Big Data Technologies</li>
        <li>Data Visualization - Analysis and Reporting</li>
       <li>Practical Machine Learning</li>
       <li>Effective Communication</li>
       <li>Aptitude & General English</li>
       <li>Project </li>  
    </p>
      </div>
      </>
    );
  }
}

export default Dbda;
