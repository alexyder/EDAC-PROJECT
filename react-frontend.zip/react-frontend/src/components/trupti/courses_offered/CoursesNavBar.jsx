import React, { Component } from "react";
import { Link } from "react-router-dom";

class CoursesNavBar extends Component {
  render() {
    return (
      <div className="btn-group btn-block" role="group" aria-label="">
        <Link
          className="btn btn-secondary"
          to="/"
          style={{ borderRadius: "0px" }}
        >
          Back
        </Link>
        <Link
          className="btn btn-danger"
          to="/coursesoffered/DAC"
          style={{ borderRadius: "0px" }}
        >
          DAC
        </Link>

        <Link
          className="btn btn-danger"
          to="/coursesoffered/DBDA"
          style={{ borderRadius: "0px" }}
        >
          DBDA
        </Link>
        <Link
          className="btn btn-danger"
          to="/coursesoffered/AI"
          style={{ borderRadius: "0px" }}
        >
          AI
        </Link>
      </div>
    );
  }
}

export default CoursesNavBar;
