import React, { Component } from "react";
import { Link } from "react-router-dom";

class MyNavbarStudent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      code: 1,
    };
  }

  checkSubject = (event) => {
    if (event.target.value === "Select Subject") {
      this.setState({ code: 1 });

      const xx = document.createElement("a");
      xx.href = "/dashboard";
      xx.click();
    } else {
      this.setState({ code: 0 });
      localStorage.setItem("subject", document.getElementById("sub").value);
    }
  };

  componentDidMount() {
    if (localStorage.getItem("course") === "DAC") {
      document.getElementById("s1").innerHTML = "Core Java";
      document.getElementById("s2").innerHTML = "Advance Java";
      document.getElementById("s3").innerHTML = "Database";
    } else if (localStorage.getItem("course") === "DBDA") {
      document.getElementById("s1").innerHTML = "Python";
      document.getElementById("s2").innerHTML = "Big Data";
      document.getElementById("s3").innerHTML = "Maching Learning";
    } else {
      document.getElementById("s1").innerHTML = "Artificial Intelligence";
      document.getElementById("s2").innerHTML = "Neural Networks";
      document.getElementById("s3").innerHTML = "Data Analytics";
    }
  }

  render() {
    return (
      <div className="btn-group btn-block" role="group" aria-label="">
        <Link
          className="btn btn-secondary"
          to="/"
          style={{ borderRadius: "0px" }}
        >
          Back
        </Link>
        <Link className="btn btn-success" to="/dashboard/viewteacherdetails">
          Teacher Details
        </Link>
        <Link className="btn btn-success" to="/dashboard/projectsuggestions">
          Project Ideas
        </Link>
        <Link
          to="/dashboard/viewcoursenotifications"
          className="btn btn-success"
        >
          Course Notifications
        </Link>
        <Link to="/dashboard/coursematerial" className="btn btn-success">
          Course Material
        </Link>
        <Link to="#">
          <select
            id="sub"
            className="btn btn-success"
            onChange={this.checkSubject}
            style={{ borderRadius: "0px" }}
          >
            <option defaultValue>Select Subject</option>
            <option id="s1"></option>
            <option id="s2"></option>
            <option id="s3"></option>
          </select>
        </Link>
        <Link to="/dashboard/askqueries">
          <button
            style={{ borderRadius: "0px" }}
            className="btn btn-success"
            disabled={this.state.code === 1 ? true : false}
          >
            Queries
          </button>
        </Link>
        <Link to="/dashboard/assignments">
          <button
            style={{ borderRadius: "0px" }}
            className="btn btn-success"
            disabled={this.state.code === 1 ? true : false}
          >
            Assignments
          </button>
        </Link>
      </div>
    );
  }
}

export default MyNavbarStudent;
