import React from 'react';
import '../../App.css';

export default function CourseMaterial() {
  return <h1 className='course material'>Course Material</h1>;
}
