import React, { Component } from "react";
import MyNavbar from "../components/anshul/Navbar";
import UploadFile from "../components/anshul/UploadFiles";
import Backtest from "../components/Backendtest";
import Gallery from "../components/arun/Gallery.jsx";
import Login from "../components/arun/Login";
import Notification from "..//components/arun/Notification";
import Registration from "..//components/arun/Registration";
import StudentQuery from "../components/arun/StudentQuery";
import Writequery from "../components/arun/Writequery";
import { Link } from "react-router-dom";
import Achivements from "../components/arun/Achivements";
import Center from "../components/arun/Center";
import FacultyRegistration from "../components/arun/FacultyRegistration";

class Home extends React.Component {
  render() {
    return (
      <div>
        <MyNavbar />

        {/* <div className="splitScreen">

              <div className="leftpane"><Gallery/></div>
                
               
              <div className="middlePane"><Notification/></div> 
                
             
              <div className="rightpane"><Login/> </div> */}

        {/* <Link
          style={{ marginLeft: "10px" }}
          className="buttonhigh"
          to="/Writequery"
        >
          <span>Write query</span>
        </Link>
        <Link
          style={{ marginLeft: "10px" }}
          className="buttonhigh"
          to="/responsequery"
        >
          <span >check response</span>
        </Link> 
         */}

        <Link
          style={{ marginLeft: "10px" }}
          className="buttonhigh"
          to="/Achive"
        >
          <span>Achievements</span>
        </Link>
        <div className="splitScreen2">
          <div className="leftpane2">
            <Center />
          </div>

          <div className="rightpane2">
            <FacultyRegistration />
          </div>
        </div>
      </div>
    );
  }
}

export default Home;
