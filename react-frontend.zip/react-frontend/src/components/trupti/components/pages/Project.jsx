import React from 'react';

export default function Project() {
  return (
    <>
      <h1 className='project'>project details here</h1>
    </>
  );
}
