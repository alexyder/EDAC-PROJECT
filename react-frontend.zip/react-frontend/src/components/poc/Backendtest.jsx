import React, { Component } from "react";
import Sprint1 from "../../services/Sprint1";

class Backtest extends Component {
  constructor(props) {
    super(props);

    this.state = {
      xyz: "hello brooo",
      trupti: "singh rathore",
      arun: "a boy",
    };
  }

  buttonclicked = () => {
    console.log("successfully clicked the button");

    Sprint1.test1().then((res) => {
      this.setState({ xyz: res.data });
    });
  };

  render() {
    return (
      <div>
        Demo component at work {this.state.xyz}
        <br />
        <button onClick={this.buttonclicked}>Check Backend</button>
      </div>
    );
  }
}

export default Backtest;
