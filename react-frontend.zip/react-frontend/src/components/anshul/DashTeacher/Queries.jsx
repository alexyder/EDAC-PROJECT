import React, { Component } from "react";
import Sprint1 from "../../../services/Sprint1";

class Queries extends Component {
  constructor(props) {
    super(props);
    this.state = {
      reply: "",
      queries: [],
      currentcourse: "",
      currentsubject: "",
    };
  }

  clearreply = (qid) => {
    this.setState({ reply: "" });
    document.getElementById(qid).value = "";
  };
  changeHandler = (e) => {
    this.setState({ reply: e.target.value });
  };

  sendreply = (qid) => {
    // console.log("Sending reply => " + this.state.reply);

    if (this.state.reply !== "") {
      Sprint1.teacherReplyingQuery(qid, this.state.reply)
        .then((res) => {
          // console.log(res.data);
          document.getElementById(qid).value = "";
          this.setState({ reply: "" });
          if (res.status === 200) {
            document.getElementById(qid + 100).innerHTML = "Replied";
            this.updatingReply();
          }
        })
        .catch(() => {
          document.getElementById(qid + 100).innerHTML = "Server Error";
        });
    } else {
      document.getElementById(qid + 100).innerHTML = "Cannot Send Empty Reply";
    }
  };

  updatingReply() {
    // console.log(this.state.currentcourse + "-" + this.state.currentsubject);
    Sprint1.teacherViewingQuery(
      this.state.currentcourse,
      this.state.currentsubject
    ).then((res) => {
      this.setState({ queries: res.data });
    });
  }

  updatingQuery() {
    Sprint1.teacherViewingQuery(
      localStorage.getItem("course"),
      localStorage.getItem("module")
    )
      .then((res) => {
        if (res.status === 200) {
          this.setState({ queries: res.data });
          this.setState({ currentcourse: localStorage.getItem("course") });
          this.setState({ currentsubject: localStorage.getItem("module") });
          // let a = this.state.currentcourse;
          // let b = this.state.currentsubject;
          // let c = localStorage.getItem("course");
          // let d = localStorage.getItem("module");

          // console.log(a + " = " + c);
          // console.log(b + " = " + d);
        }
      })
      .catch(() => {
        console.log("Queries not found");
      });
  }

  render() {
    if (
      localStorage.getItem("course") !== this.state.currentcourse ||
      localStorage.getItem("module") !== this.state.currentsubject
    ) {
      // console.log("calling updatequery");
      this.updatingQuery();
    }
    return (
      <div>
        You can reply to subject related queries
        <hr />
        <br />
        <div style={{ marginLeft: "20px", marginRight: "20px" }}>
          <div
            style={{ marginRight: "80%", height: "55px" }}
            className="alert alert-success"
            role="alert"
          >
            <b>
              <label>{localStorage.getItem("module")} Queries</label>
            </b>
          </div>
          {this.state.status}
          <div style={{ paddingRight: "20px" }}>
            <table className="table table-striped">
              <thead className="thead-dark">
                <tr className="tab-pane">
                  <th> Student Id</th>

                  <th> Student's Query</th>
                  <th> Reply</th>
                  <th> My Response</th>
                </tr>
              </thead>

              <tbody>
                {this.state.queries.map((qobj) => (
                  <tr key={qobj.qid}>
                    <td>{qobj.prn}</td>

                    <td>{qobj.que}</td>
                    <td>
                      <textarea
                        style={{
                          resize: "vertical",
                          backgroundColor: "oldlace",
                          borderRadius: "3px",
                        }}
                        id={qobj.qid}
                        rows="2"
                        cols="50"
                        onChange={this.changeHandler}
                      ></textarea>

                      <div>
                        <button
                          className=" btn-secondary"
                          onClick={() => this.sendreply(qobj.qid)}
                        >
                          Send
                        </button>
                        <button
                          className=" btn-warning"
                          onClick={() => this.clearreply(qobj.qid)}
                        >
                          Clear
                        </button>
                        <h6 style={{ color: "grey" }} id={qobj.qid + 100}></h6>
                      </div>
                    </td>
                    <td>{qobj.reply}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  }
}

export default Queries;
