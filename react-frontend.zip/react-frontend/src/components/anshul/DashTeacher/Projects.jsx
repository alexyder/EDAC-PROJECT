import React, { Component } from "react";

class Projects extends Component {
  render() {
    return (
      <div>
        Hello Teacher... you can add project suggestions from here
        <hr />
      </div>
    );
  }
}

export default Projects;
