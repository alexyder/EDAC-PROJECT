import React from "react";
import Sprint1 from "../services/Sprint1";
// import "./Arun.css";

class Notification extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      noti: [],
    };
  }

  componentDidMount = () => {
    Sprint1.getPublicNotifications()
      .then((res) => {
        // console.log("mystatus => " + res.status);
        if (res.status === 200) {
          this.setState({ noti: res.data });
        }
      })
      .catch((res) => {
        console.log("No Public Notifications => " + res.data);
      });
  };

  render() {
    return (
      <div className="card" style={{ width: "100%" }}>
        <div
          style={{
            paddingLeft: "10px",
            paddingTop: "6px",
            height: "40px",
            marginBottom: "-1px",
            borderBottomLeftRadius: "0px",
            borderBottomRightRadius: "0px",
          }}
          className="alert alert-info"
        >
          <b>
            <h5>Notifications and Updates</h5>
          </b>
        </div>
        <div className="table-box">
          <table className="table table-bordered">
            <tbody>
              {this.state.noti.map((nn) => (
                <tr key={nn.id}>
                  <td style={{ color: "#e6004c", width: "110px" }}>
                    {" "}
                    {nn.uptime}{" "}
                  </td>
                  <td> {nn.msg} </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}

export default Notification;
