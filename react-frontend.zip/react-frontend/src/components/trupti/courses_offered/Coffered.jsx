import React, { Component } from "react";
import { Route, Switch } from "react-router";
import AiPage from "./Ai";
import CoursesNavBar from "./CoursesNavBar";
import DacPage from "./Dac";
import DbdaPage from "./Dbda";

export default class Coffered extends Component {
  render() {
    return (
      <div>
        <CoursesNavBar />
        <br />
        <br />
        <br />
        <Switch>
          <Route path="/coursesoffered/DAC" component={DacPage}></Route>
          <Route path="/coursesoffered/DBDA" component={DbdaPage}></Route>
          <Route path="/coursesoffered/AI" component={AiPage}></Route>
        </Switch>
      </div>
    );
  }
}
