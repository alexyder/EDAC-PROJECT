import React, { Component } from "react";
import Sprint2 from "../../../services/Sprint2";

class ViewStudents extends Component {
  constructor(props) {
    super(props);
    this.state = {
      allstudents: [],
      currentcourse: "",
    };
  }

  seeStudents() {
    Sprint2.viewStudents(localStorage.getItem("course"))
      .then((res) => {
        if (res.status === 200) {
          this.setState({ allstudents: res.data });
          this.setState({ currentcourse: localStorage.getItem("course") });
        }
      })
      .catch(() => {
        console.log("Students not Found");
      });
  }

  render() {
    if (localStorage.getItem("course") !== this.state.currentcourse) {
      this.seeStudents();
    }
    return (
      <div>
        <hr />

        <div
          className="container"
          style={{
            paddingLeft: "10%",
            paddingRight: "10%",
          }}
        >
          <div className="alert alert-success" style={{ height: "50px" }}>
            <h5>List of {localStorage.getItem("course")} Students</h5>
          </div>
          <hr />
          <table
            className="table table-striped table-bordered"
            style={{ backgroundColor: "SeaShell" }}
          >
            <thead>
              <tr>
                <th> Prn No.</th>
                <th> Student Name</th>
              </tr>
            </thead>
            <tbody>
              {this.state.allstudents.map((sobj) => (
                <tr key={sobj.prn}>
                  <td>{sobj.prn}</td>
                  <td> {sobj.fullname} </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}

export default ViewStudents;
