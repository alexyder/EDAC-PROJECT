import React from 'react';
import '../../App.css';

export default function Results() {
  return <h1 className='results'>display result</h1>;
}
