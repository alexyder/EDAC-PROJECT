import React from 'react';
import '../../App.css';

export default function Course() {
  return <h1 className='course'>Course</h1>;
}
