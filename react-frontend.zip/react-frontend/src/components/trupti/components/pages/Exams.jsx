import React from 'react';
import '../../App.css';

export default function Exams() {
  return <h1 className='exams'>your exams </h1>;
}
