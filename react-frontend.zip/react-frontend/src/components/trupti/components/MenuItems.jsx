export const MenuItems = [
  {
    title: "java",
    path: "/",
    cName: "dropdown-link",
  },
  {
    title: "dbt",
    path: "/",
    cName: "dropdown-link",
  },
  {
    title: "Data Strucutre",
    path: "/",
    cName: "dropdown-link",
  },
];
