import React from "react";
import "./Arun.css";

const register = (
  <>
    <div className="table-Ar">
      <form>
        <h1 className="heading">Registration form</h1>
        <table>
          <h2>Basic Details</h2>
          <tr>
            <td>Tid no. - </td>
          </tr>

          <tr>
            <td>GENDER</td>
            <td>
              <input type="text" name="gender" />
            </td>
            <td>DATE OF BIRTH</td>
            <td>
              <input type="date" name="dob" />
            </td>
          </tr>

          <tr>
            <td>MOBILE NO</td>
            <td>
              <input type="number" name="mobile" />
            </td>
            <td>EMAIL</td>
            <td>
              <input type="email" name="email" />
            </td>
          </tr>

          <tr>
            <td>yoe</td>
            <td>
              <input type="text" name="state" />
            </td>
            <td>DESIG.</td>
            <td>
              <input type="text" name="state" />
            </td>
          </tr>

          <tr />
          <br />
          <br />
          <br />
          <tr>
            {" "}
            <td />
            <td>
              <button className="button" id="submit">
                SAVE
              </button>
            </td>
            <td>
              <button className="button" id="edit">
                SKIP
              </button>{" "}
            </td>
          </tr>
          <br />
          <br />
          <br />
        </table>
      </form>
    </div>
  </>
);

function Registration() {
  return register;
}

export default Registration;
