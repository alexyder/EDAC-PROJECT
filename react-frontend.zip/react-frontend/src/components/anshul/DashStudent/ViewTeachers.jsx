import React, { Component } from "react";
import Sprint2 from "../../../services/Sprint2";

export default class ViewTeachers extends Component {
  constructor(props) {
    super(props);
    this.state = {
      allteachers: [],
    };
  }

  componentDidMount = () => {
    Sprint2.getTeacherDetails()
      .then((res) => {
        // console.log(res.data);
        if (res.status === 200) {
          this.setState({ allteachers: res.data });
        }
      })
      .catch(() => {
        console.log("Teachers Not Found");
      });
  };

  render() {
    return (
      <div className="container">
        <br />
        <div
          className="alert alert-success"
          style={{ height: "50px", textAlign: "center" }}
        >
          <h4>Teacher Details</h4>
        </div>
        <br />
        <div className="row">
          <table
            className="table table-striped table-bordered"
            style={{ backgroundColor: "SeaShell" }}
          >
            <thead>
              <tr>
                <th> Name</th>
                <th> Designation</th>
                <th> Gender</th>
                <th> Experience ( Years )</th>
                <th> Email-Id</th>
              </tr>
            </thead>
            <tbody>
              {this.state.allteachers.map((tobj) => (
                <tr key={tobj.tid}>
                  <td> {tobj.fullname} </td>
                  <td>{tobj.desig}</td>
                  <td>{tobj.gender}</td>
                  <td>{tobj.yoe}</td>
                  <td>{tobj.email}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}
