import React from 'react';
import '../../App.css';

export default function Logout() {
  return <h1 className='logout'>Logged Out Successfully</h1>;
}
