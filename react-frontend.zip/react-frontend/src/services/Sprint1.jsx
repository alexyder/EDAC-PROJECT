import axios from "axios";

const BASE_URL = "http://localhost:7777";

class Sp1 {
  // WORKING
  setPublicNotifications(newnoti) {
    let data = { msg: newnoti };
    return axios.post(BASE_URL + "/gnoti", data);
  }

  // WORKING
  getPublicNotifications() {
    return axios.get(BASE_URL + "/gnoti");
  }

  // WORKING
  loginstudent(x) {
    return axios.post(BASE_URL + "/loginst", x);
  }

  // WORKING
  loginteacher(y) {
    return axios.post(BASE_URL + "/loginte", y);
  }

  // WORKING
  askQuery() {
    let x = {
      prn: "1234",
      module: "m3",
      que: "why this kolaver di ?",
    };
    return axios.post(BASE_URL + "/askquery", x);
  }

  // WORKING
  studentViewingQuery() {
    let prn = 1234;
    return axios.get(BASE_URL + "/viewqueryst/" + prn);
  }

  // WORKING
  teacherViewingQuery(course, module) {
    return axios.get(BASE_URL + "/viewqueryte/" + course + "/" + module);
  }

  // WORKING
  teacherReplyingQuery(qid, replied) {
    let x = { reply: replied };
    return axios.post(BASE_URL + "/replyquery/" + qid, x);
  }

  // WORKING
  studentRegistration() {
    let prn = "12";
    let data = {
      gender: "male",
      dob: "24-03-97",
      phone: "123456789",
      email: "123@xyz",
      address: "",
      city: "",
      state: "",
      country: "",
      course: "",
      batch: "",
    };
    return axios.post(BASE_URL + "/stureg/" + prn, data);
  }

  // WORKING
  studentViewingProfile() {
    let prn = "12";
    return axios.get(BASE_URL + "/viewprofilest/" + prn);
  }

  // WORKING
  studentUpdatingProfile() {
    let prn = "12";
    let data = {
      gender: "female",
      dob: "24-03-97",
      phone: "123456789",
      email: "456@xyz",
      address: "",
      city: "",
      state: "",
      country: "",
      course: "",
      batch: "",
    };
    return axios.put(BASE_URL + "/stureg/" + prn, data);
  }

  // WORKING
  teacherRegistration() {
    let tid = "96";
    let data = {
      gender: "female",
      phone: "123456789",
      email: "456@xyz",
      yoe: "",
      desig: "",
    };
    return axios.post(BASE_URL + "/teareg/" + tid, data);
  }

  // WORKING
  teacherViewingProfile() {
    let tid = "96";
    return axios.get(BASE_URL + "/viewprofilete/" + tid);
  }

  // WORKING
  teacherUpdatingProfile() {
    let tid = "96";
    let data = {
      gender: "male",
      phone: "123456789",
      email: "456@xyz",
      yoe: "",
      desig: "Teacher HD",
    };
    return axios.put(BASE_URL + "/teareg/" + tid, data);
  }
}

export default new Sp1();
