export const MenuItems = [
    {
      title: 'DAC',
      path: '/',
      cName: 'dropdown-link'
    },
    {
      title: 'DBDA',
      path: '/dbda',
      cName: 'dropdown-link'
    },
    {
      title: 'AI',
      path: '/',
      cName: 'dropdown-link'
    },
  ];
  
  
  