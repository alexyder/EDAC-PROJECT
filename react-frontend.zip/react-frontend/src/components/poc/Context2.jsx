import React from "react";
import { createContext } from "react";

const Fname = createContext();

const data = {
  course: "DAC",
  subject: "Core-Java",
};

function My() {
  return (
    <div>
      <h2>Mobile</h2>
      <h3>redmi</h3>
      <Fname.Provider value={data}></Fname.Provider>
    </div>
  );
}

export default My;
export { Fname };
