import React, { Component } from "react";

import { Route, Switch } from "react-router-dom";
import DashHeader from "../DashTeacher/DashHeader";
import MyNavbarStudent from "../MyNavBarStudent";
import Assignments from "./Assignments";
import CourseMaterial from "./CourseMaterial";
import ProjectIdeas from "./ProjectIdeas";
import QueriesAsk from "./QueriesAsk";
import ViewCourseNoti from "./ViewCourseNoti";
import ViewTeachers from "./ViewTeachers";

class DashStudent extends Component {
  render() {
    return (
      <div>
        <MyNavbarStudent />
        <div style={{ paddingLeft: "25px" }}>
          <h4>
            <br />
            <div>
              <h5>Welcome , {localStorage.getItem("username")}</h5>
              <hr />
              <h6> ID - {localStorage.getItem("id")}</h6>
              <h6>Course - {localStorage.getItem("course")}</h6>
            </div>
          </h4>
          <hr />
          <Switch>
            <Route path="/dashboard" exact component={DashHeader}></Route>
            <Route
              path="/dashboard/viewcoursenotifications"
              component={ViewCourseNoti}
            ></Route>
            <Route
              path="/dashboard/viewteacherdetails"
              component={ViewTeachers}
            ></Route>
            <Route path="/dashboard/askqueries" component={QueriesAsk}></Route>
            <Route
              path="/dashboard/projectsuggestions"
              component={ProjectIdeas}
            ></Route>
            <Route
              path="/dashboard/coursematerial"
              component={CourseMaterial}
            ></Route>

            {/* COMING SOON - ASSIGNMENTS */}

            <Route
              path="/dashboard/assignments"
              component={Assignments}
            ></Route>
          </Switch>
        </div>
      </div>
    );
  }
}

export default DashStudent;
