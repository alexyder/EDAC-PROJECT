import React from "react";

function CollegeCard(props) {
  return (
    <div className="card">
      <img src={props.img} alt="Avatar" style={{ width: "100%" }}></img>
      <div className="container">
        <h4>
          <b>{props.region} Region</b>
        </h4>
        <ul>{props.clg}</ul>
      </div>
    </div>
  );
}

export default CollegeCard;
