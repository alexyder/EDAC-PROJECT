import React, { Component } from "react";
import Sprint3 from "../../../services/Sprint3";

export default class CourseMaterial extends Component {
  constructor(props) {
    super(props);
    this.state = {
      myfiles: [],
    };
  }

  componentDidMount() {
    Sprint3.getFilesForStudent(localStorage.getItem("course")).then((res) => {
      // console.log(res.data);
      this.setState({ myfiles: res.data });
    });
  }

  downloadfile(fileid, fileName) {
    // console.log(data);
    Sprint3.downloadFile(fileid).then((res) => {
      // console.log(JSON.stringify(res.data.fileName));

      const url = window.URL.createObjectURL(new Blob([res.data]));
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", fileName);
      document.body.appendChild(link);
      link.click();

      // <a href="url" download=""></a>
    });
  }

  render() {
    return (
      <div>
        You can download course materials from here
        <hr />
        <div className="container">
          <div className="row">
            <table
              className="table table-striped table-bordered"
              style={{ backgroundColor: "SeaShell" }}
            >
              <thead>
                <tr>
                  <th> fileName</th>
                  <th> fileType</th>
                  <th> Course</th>
                </tr>
              </thead>
              <tbody>
                {this.state.myfiles.map((file) => (
                  <tr key={file.id}>
                    <td> {file.filename} </td>
                    <td>{file.filetype}</td>
                    <td>{file.course}</td>

                    <td>
                      <button
                        className="btn btn-success"
                        onClick={() =>
                          this.downloadfile(file.id, file.filename, file.data)
                        }
                      >
                        Download
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  }
}
