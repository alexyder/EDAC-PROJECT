import React, { Component } from "react";
import Sprint1 from "../../services/Sprint1";

class Demo extends Component {
  constructor(props) {
    super(props);

    this.state = {
      id: "",
      pwd: "",
      user: "",
    };
  }

  checkplease = (e) => {
    e.preventDefault();
    Sprint1.test1().then((res) => {
      console.log(res.data);
    });
  };

  changeUSerHandler = (event) => {
    this.setState({ user: event.target.value });
  };

  changeIDHandler = (event) => {
    this.setState({ id: event.target.value });
  };

  changePassHandler = (event) => {
    this.setState({ pwd: event.target.value });
  };

  render() {
    return (
      <div>
        <input type="submit" id="log" value="TEST" onClick={this.checkplease} />
      </div>
    );
  }
}

export default Demo;
