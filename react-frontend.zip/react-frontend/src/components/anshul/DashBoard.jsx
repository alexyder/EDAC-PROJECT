import React, { Component } from "react";
import DashStudent from "./DashStudent/DashStudent";
import DashTeacher from "./DashTeacher/DashTeacher";

class DashBoard extends Component {
  render() {
    if (localStorage.getItem("user") === "teacher") {
      return (
        <div>
          <DashTeacher />
          <div>
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
          </div>
        </div>
      );
    } else if (localStorage.getItem("user") === "student") {
      return (
        <div>
          <DashStudent />
          <div>
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
          </div>
        </div>
      );
    } else {
      return (
        <div style={{ backgroundColor: "white", paddingLeft: "22%" }}>
          <div
            style={{
              backgroundImage: `url("https://cdn.dribbble.com/users/1191447/screenshots/3829052/error_shot.gif")`,
              backgroundRepeat: "no-repeat",
            }}
          >
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
          </div>
        </div>
      );
    }
  }
}

export default DashBoard;
