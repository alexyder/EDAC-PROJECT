import React from "react";
import Sprint2 from "../../../services/Sprint2";
// import "./Arun.css";

class ViewCourseNoti extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      noti: [],
    };
  }

  componentDidMount = () => {
    Sprint2.getCourseNotifications(localStorage.getItem("id"))
      .then((res) => {
        if (res.status === 200) {
          this.setState({ noti: res.data });
        }
      })
      .catch(() => {
        console.log("Course Notifications not Found");
      });
  };

  render() {
    return (
      <div
        className="container"
        style={{
          paddingLeft: "5%",
          paddingRight: "5%",
          textAlign: "center",
        }}
      >
        <div className="alert alert-success" style={{ height: "50px" }}>
          <h5>Notifications and Updates</h5>
        </div>
        <hr />
        <table
          className="table table-striped table-bordered"
          style={{ backgroundColor: "SeaShell" }}
        >
          <thead></thead>
          <tbody>
            {this.state.noti.map((n) => (
              <tr key={n.id}>
                <td>{n.uptime}</td>
                <td> {n.msg} </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }
}

export default ViewCourseNoti;
