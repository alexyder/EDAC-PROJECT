import React, { Component } from "react";
import "./anshul.css";
import MyNavbar from "./MyNavbar";

class AboutUs extends Component {
  render() {
    return (
      <div>
        <MyNavbar />
        <div className="Mymargin" style={{ background: "rgba(0,0,0, 0.0)" }}>
          <div>
            <br />
            <br />
            <img
              style={{
                borderRadius: "10px",
              }}
              src="https://i.ytimg.com/vi/Y91mu1qhoMU/maxresdefault.jpg"
              alt="cdac bangalore"
              width="800"
              height="400"
            ></img>
          </div>
          <br />
          <h4>About Centre:</h4>
          <p>
            C-DAC, Bengaluru centre, is the 2nd of C DAC centres to be
            established in 1989 to carry-out research and deliver solutions and
            products in the area of System Software for PARAM series of super
            computers of C-DAC. PARAM Padma, housed at C-DAC's Terascale
            Supercomputing Facility (CTSF) is a result of its third mission
            project in High Performance Computing Technologies. The centre is
            highly acclaimed as a centre for excellence in the thematic areas of
            High Performance and Grid Computing, Cyber Security and Cyber
            Forensic, Professional Electronics, FOSS and Software Technologies,
            Language and Heritage Computing and Training
          </p>

          <h5>Mission</h5>

          <ul>
            <li>Deliver cutting edge computing technologies</li>
            <li>
              Continue to maintain strengths in System Software Development
            </li>
            <li>Indigenously develop generic automation technologies</li>
            <li>Cater to the automation of everyday objects and activities</li>
            <li>Preserve and propagate the rich Indian Heritage</li>
            <li>Impart quality training in high-end technologies</li>
          </ul>

          <h5>Main Objectives of C-DAC Bengaluru are:</h5>

          <ul>
            <li>
              Enhancing India's role as a leader in Software Engineering and
              Allied Disciplines.
            </li>
            <li>
              To Carry out R & D in Software-intensive Systems and Technologies.
            </li>
            <li>To provide training & education in Software Engineering.</li>
          </ul>
        </div>
      </div>
    );
  }
}

export default AboutUs;
