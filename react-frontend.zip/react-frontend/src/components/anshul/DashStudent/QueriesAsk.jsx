import React, { Component } from "react";
import Sprint2 from "../../../services/Sprint2";

export default class QueriesAsk extends Component {
  constructor(props) {
    super(props);
    this.state = {
      text: "",
      status: "",
      queries: [],
    };
  }
  sendQuery = () => {
    if (this.state.text !== "") {
      let qobj = {
        prn: localStorage.getItem("id"),
        module: localStorage.getItem("subject"),
        que: this.state.text,
      };
      Sprint2.askQuery(qobj)
        .then((res) => {
          if (res.status === 200) {
            this.setState({ status: res.data });
            // console.log("query asked");
            this.updateMyQuery();
          }
        })
        .catch(() => {
          this.setState({ status: "Failed to send query (server error)" });
        });
      // initializing
      document.getElementById("xyz").value = "";
      this.setState({ text: "" });
    } else {
      this.setState({ status: "Cannot Send Empty Query" });
    }
  };

  updateMyQuery() {
    Sprint2.viewQuerySt(localStorage.getItem("id"))
      .then((res) => {
        if (res.status === 200) {
          this.setState({ queries: res.data });
          // console.log("queries updated");
        }
      })
      .catch(() => {
        console.log("Queries not Found");
      });
  }

  componentDidMount() {
    Sprint2.viewQuerySt(localStorage.getItem("id"))
      .then((res) => {
        if (res.status === 200) {
          this.setState({ queries: res.data });
        }
      })
      .catch(() => {
        console.log("Queries not found");
      });
  }

  changeHandler = (e) => {
    this.setState({ text: e.target.value });
    this.setState({ status: "" });
  };

  clearing = () => {
    document.getElementById("xyz").value = "";
    this.setState({ text: "" });
  };

  render() {
    return (
      <div>
        You can manage your Queries from here
        <hr />
        <div className="container">
          <b>
            <label>
              Enter Your Query for {localStorage.getItem("subject")}
            </label>
          </b>
          <br />
          <textarea
            style={{
              resize: "both",
              backgroundColor: "oldlace",
              borderRadius: "5px",
            }}
            id="xyz"
            rows="4"
            cols="100"
            onChange={this.changeHandler}
          ></textarea>
          <div className="btn-group btn-block" role="group" aria-label="">
            <div>
              <br />
              <button
                style={{
                  borderTopRightRadius: "0px",
                  borderBottomRightRadius: "0px",
                }}
                className=" btn btn-success"
                onClick={this.sendQuery}
              >
                Send
              </button>
              <button
                className="btn btn-warning"
                style={{
                  borderTopLeftRadius: "0px",
                  borderBottomLeftRadius: "0px",
                }}
                onClick={this.clearing}
              >
                Clear
              </button>
              <hr />
            </div>
          </div>
          {this.state.status}
          <br />
          <br />

          {/* VIEWING QUERIES  */}
          <div style={{ marginRight: "85%" }} className="alert alert-success">
            <b>All Queries</b>
          </div>
          <br />
          <div style={{ paddingRight: "20px" }}>
            <table
              className="table table-striped table table-bordered"
              style={{ backgroundColor: "SeaShell" }}
            >
              <thead className="thead-dark">
                <tr className="tab-pane">
                  <th> Subject</th>
                  <th> MyQuery</th>
                  <th> Response By Teacher</th>
                </tr>
              </thead>
              <tbody>
                {this.state.queries.map((qobj) => (
                  <tr key={qobj.qid}>
                    <td> {qobj.module} </td>
                    <td>{qobj.que}</td>
                    <td>{qobj.reply}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  }
}
