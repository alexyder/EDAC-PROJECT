import React, { Component } from "react";
import Two from "./Two";

export default class One extends Component {
  myfunction = () => {
    let token = false;
    console.log("myfunction of one.jsx " + token);
  };
  render() {
    return (
      <div>
        one.jsx called
        <Two xx={this.myfunction} />
      </div>
    );
  }
}
