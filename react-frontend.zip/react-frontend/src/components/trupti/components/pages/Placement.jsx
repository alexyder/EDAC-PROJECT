import React from 'react';

export default function Placement() {
  return (
    <>
      <h1 className='placement'>placement details</h1>
    </>
  );
}
