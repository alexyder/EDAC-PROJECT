import React, { Component } from "react";

class Assignments extends Component {
  render() {
    return (
      <div>
        Teacher can add assignments from here ..
        <hr />
        <div
          className="container , card"
          style={{
            width: "30%",
            textAlign: "center",
            backgroundColor: "lightyellow",
            color: "darkgreen",
          }}
        >
          <h4>Coming Soon ...</h4>
        </div>
      </div>
    );
  }
}

export default Assignments;
