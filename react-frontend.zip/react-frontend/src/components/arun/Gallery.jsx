import React from "react";
import "./Arun.css";

const img1 = "https://i.ytimg.com/vi/Y91mu1qhoMU/maxresdefault.jpg";
const img2 = "https://i.ytimg.com/vi/KhLZWtbSg9E/maxresdefault.jpg";
const img3 =
  "https://images.jdmagicbox.com/comp/bangalore/48/080ps001148/catalogue/centre-for-development-of-advanced-computing-byappanahalli-bangalore-computer-software-training-institutes-byp2qtl1tp.jpg";
const img4 = "https://i.ytimg.com/vi/EPyZbHHqNis/hqdefault.jpg";

const images = (
  <div
    style={{
      border: "8px ridge silver",
      height: "300px",
      paddingRight: "3px",
      width: "105%",
    }}
  >
    <div
      // className="alert"
      style={{
        marginTop: "2px",
        backgroundColor: "Khaki",
        textAlign: "center",
        paddingTop: "15px",
        marginLeft: "5px",
        color: "Sienna",
        paddingBottom: "5px",
      }}
    >
      <h4>Gallery</h4>
      <br />
    </div>
    <a href={img1}>
      <img className="imglog" src={img1} />
    </a>
    <a href={img2}>
      <img className="imglog" src={img2} />
    </a>
    <a href={img3}>
      <img className="imglog" src={img3} />
    </a>
    <a href={img4}>
      <img className="imglog" src={img4} />
    </a>
  </div>
);

function Gallery() {
  return images;
}

export default Gallery;
