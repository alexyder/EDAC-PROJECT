import React, { Component } from "react";
import Sprint2 from "../../../services/Sprint2";

class CourseNotifications extends Component {
  constructor(props) {
    super(props);
    this.state = {
      text: "",
      status: "",
      course: "",
    };
  }
  sendNotification = (e) => {
    if (this.state.text !== "") {
      Sprint2.setCourseNotifications(
        localStorage.getItem("course"),
        this.state.text
      )
        .then((res) => {
          if (res.status === 200) {
            this.setState({ status: "Notification Sent" });
          }
        })
        .catch(() => {
          this.setState({ status: "Server Error" });
        });
    } else {
      this.setState({ status: "Cannot Send Empty Data" });
    }

    // initializing
    document.getElementById("xyz").value = "";
    this.setState({ text: "" });
  };

  changeHandler = (e) => {
    this.setState({ text: e.target.value });
    this.setState({ status: "" });
  };

  clearing = () => {
    document.getElementById("xyz").value = "";
    this.setState({ text: "" });
  };

  render() {
    return (
      <div>
        <hr />
        You can Add Course notifications from here
        <hr />
        <div className="container">
          <b>
            <label>
              Enter Notification for {localStorage.getItem("course")}
            </label>
          </b>
          <br />
          <textarea
            style={{
              resize: "both",
              backgroundColor: "oldlace",
              borderRadius: "5px",
            }}
            id="xyz"
            rows="4"
            cols="100"
            onChange={this.changeHandler}
            placeholder="Students can view these notifications from their Dashboard"
          ></textarea>
          <div className="btn-group btn-block" role="group" aria-label="">
            <div>
              <br />
              <button
                style={{
                  borderTopRightRadius: "0px",
                  borderBottomRightRadius: "0px",
                }}
                className=" btn btn-success"
                onClick={this.sendNotification}
              >
                Send
              </button>
              <button
                className="btn btn-warning"
                style={{
                  borderTopLeftRadius: "0px",
                  borderBottomLeftRadius: "0px",
                }}
                onClick={this.clearing}
              >
                Clear
              </button>
              <hr />
            </div>
          </div>
          <div>{this.state.status}</div>
          <div>
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
          </div>
        </div>
      </div>
    );
  }
}

export default CourseNotifications;
