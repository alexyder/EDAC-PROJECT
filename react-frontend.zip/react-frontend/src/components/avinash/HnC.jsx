import React, { Component } from "react";
import MyNavbar from "../anshul/MyNavbar";
import "./avinash.css";
import HnCcards from "./HnCcards";

class HnC extends Component {
  render() {
    return (
      <div>
        <MyNavbar />
        <div className="col-container">
          <div className="col" style={{ paddingLeft: "100px" }}>
            <HnCcards
              img="https://www.refrigeratedfrozenfood.com/ext/resources/NEW_RD_Website/DefaultImages/default-pasta.jpg?1430942591"
              clg="E-City , Bangalore"
              hostel="Available"
              Aminities="Well Establisted , All basic Aminities provided"
              hFees="60000/-"
              Location="
                  No 68, Electronics City, opposite welingkar college, behing
                  bsnl office, Bengaluru, Karnataka 560100"
              Mess="Available"
              Time={
                <div>
                  <ul>
                    <li>Morning : 7-10 Am</li>
                    <li>Night : 7-10 Pm</li>
                  </ul>
                </div>
              }
              mFees="3000/- Monthly"
            />
          </div>
          <div className="col">
            <HnCcards
              img="https://img.webmd.com/dtmcms/live/webmd/consumer_assets/site_images/article_thumbnails/quizzes/fast_food_smarts_rmq/650x350_fast_food_smarts_rmq.jpg"
              clg="Knowledge Park (KP) , Bangalore"
              hostel="Not Available"
              Aminities=""
              hFees=""
              Location=""
              Mess=""
              Time=""
              mFees=""
            />
            <br />
            <br />
          </div>
        </div>
      </div>
    );
  }
}

export default HnC;
