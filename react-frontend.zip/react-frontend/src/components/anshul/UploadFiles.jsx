import React from "react";
import Sprint3 from "../../services/Sprint3";

class UploadFile extends React.Component {
  constructor(props) {
    super(props);
    // this.selectFile = this.selectFile.bind(this);
    // this.upload = this.upload.bind(this);

    this.state = {
      selectedFiles: "",
      message: "",
      fileInfos: [],
    };
  }

  componentDidMount() {
    Sprint3.getFilesForTeacher().then((res) => {
      this.setState({ fileInfos: res.data });
    });
  }

  selectFile = (event) => {
    this.setState({ message: null });
    this.setState({
      selectedFiles: event.target.files,
    });
  };

  upload = () => {
    let currentFile = this.state.selectedFiles[0];

    Sprint3.upload(currentFile, localStorage.getItem("course"))
      .then((response) => {
        console.log(response.data);
        this.setState({
          message: "File Uploaded Successfully",
        });
        return Sprint3.getFilesForTeacher();
      })
      .then((files) => {
        this.setState({
          fileInfos: files.data,
        });
      });

    this.setState({
      selectedFiles: "",
    });
    document.getElementById("xx").value = null;
  };

  render() {
    const { selectedFiles } = this.state;

    return (
      <div>
        <div
          className="card"
          style={{
            padding: "50px",
            width: "400px",
            background: "lightgray",
          }}
        >
          <h6>** All file types are supported</h6>
          <h6>** Max file size supported : 1GB</h6>
          <label className="btn btn-default">
            <input id="xx" type="file" onChange={this.selectFile} />
          </label>
          <br />
          <p style={{ color: "darkgreen" }}>{this.state.message}</p>
          <br />
          <button
            className="btn btn-success"
            disabled={!selectedFiles}
            onClick={this.upload}
          >
            Upload
          </button>
        </div>
        <br />
        <br />
        <div>
          <table
            className="table table-striped table-bordered"
            style={{ backgroundColor: "SeaShell" }}
          >
            <thead>
              <tr>
                <th> fileName</th>
                <th> fileType</th>
                <th> Course</th>
              </tr>
            </thead>
            <tbody>
              {this.state.fileInfos.map((file) => (
                <tr key={file.id}>
                  <td> {file.filename} </td>
                  <td>{file.filetype}</td>
                  <td>{file.course}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}

export default UploadFile;
