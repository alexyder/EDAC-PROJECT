import React, { Component } from "react";
import { Link } from "react-router-dom";
import Sprint1 from "../services/Sprint1";

class Login extends Component {
  constructor(props) {
    super(props);

    this.state = {
      id: "",
      pwd: "",
      user: "",
      msg: "",
    };
  }

  checklogin = (e) => {
    e.preventDefault();
    if (this.state.user === "teacher") {
      let credential = { tid: this.state.id, pwd: this.state.pwd };
      Sprint1.loginteacher(credential)
        .then((res) => {
          console.log(res.data);
          if (res.status === 200) {
            // console.log("teacher login successful");
            this.setState({ msg: "" });
            localStorage.setItem("id", this.state.id);
            localStorage.setItem("username", res.data);
            localStorage.setItem("user", this.state.user);
            window.location.reload(false);
          }
        })
        .catch(() => {
          this.setState({ msg: "Incorrect Id/Password" });
        });
    } else if (this.state.user === "student") {
      let credential = { prn: this.state.id, pwd: this.state.pwd };
      Sprint1.loginstudent(credential)
        .then((res) => {
          console.log(res.data);
          if (res.status === 200) {
            // console.log("student login successful");
            this.setState({ msg: "" });
            localStorage.setItem("id", this.state.id);
            localStorage.setItem("username", res.data);
            localStorage.setItem("user", this.state.user);

            let id = (this.state.id / 10000000).toFixed();
            let course;
            if (id === "101") {
              course = "DAC";
            } else if (id === "102") {
              course = "DBDA";
            } else if (id === "103") {
              course = "AI";
            }
            localStorage.setItem("course", course);
            window.location.reload(false);
          }
        })
        .catch(() => {
          this.setState({ msg: "Incorrect Id/Password" });
        });
    } else {
      this.setState({ msg: "Select student/teacher" });
    }
  };

  // logoutplease = () => {
  //   this.setState({ code: 0 });
  //   localStorage.removeItem("id");
  //   localStorage.removeItem("username");
  //   localStorage.removeItem("user");
  //   window.location.reload(false);
  // };

  changehandler = (event) => {
    this.setState({ [event.target.name]: event.target.value });
  };

  render() {
    if (localStorage.getItem("id") === null) {
      return (
        <div
          className="card"
          style={{
            width: "99%",
            height: "50%",
            backgroundColor: "oldlace",
            paddingTop: "",
          }}
        >
          <div className="login">
            <form>
              <h4>User Login</h4>
              <label style={{ width: "20px" }}>
                <input
                  required
                  type="radio"
                  onChange={this.changehandler}
                  name="user"
                  value="teacher"
                />
              </label>
              Teacher
              <br />
              <label style={{ width: "20px" }}>
                <input
                  required
                  type="radio"
                  onChange={this.changehandler}
                  name="user"
                  value="student"
                />
              </label>
              Student
              <br />
              <table>
                <tbody>
                  <tr>
                    <td>User-Id</td>
                    <td>
                      <input
                        style={{ marginLeft: "10px" }}
                        className="inputfields"
                        onChange={this.changehandler}
                        placeholder="Enter user ID"
                        type="number"
                        name="id"
                      />
                    </td>
                  </tr>
                  <tr>
                    <td>Password</td>
                    <td>
                      <input
                        style={{ marginLeft: "10px" }}
                        required
                        className="inputfields"
                        onChange={this.changehandler}
                        placeholder="Enter Password"
                        type="Password"
                        name="pwd"
                      />
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <br />
                      <input
                        className="btn btn-success"
                        type="submit"
                        id="log"
                        value="Login"
                        onClick={this.checklogin}
                      />
                    </td>
                    <td>
                      <p
                        id="m"
                        style={{
                          paddingLeft: "30px",
                          color: "FireBrick",
                          paddingTop: "40px",
                        }}
                      >
                        {this.state.msg}
                      </p>
                    </td>
                  </tr>
                </tbody>
              </table>
            </form>
          </div>
        </div>
      );
    } else {
      return (
        <div
          className="card"
          style={{
            width: "99%",
            height: "50%",
            backgroundColor: "oldlace",
            paddingTop: "",
          }}
        >
          <div className="login">
            <h5>
              <b> Welcome , {localStorage.getItem("username")} </b>
            </h5>
            <hr />
            <br />
            <br />
            <br />
            <Link className="btn btn-secondary btn-block" to="/dashboard">
              DashBoard
            </Link>
            <button
              className="btn btn-danger btn-block"
              onClick={() => {
                this.setState({ code: 0 });
                localStorage.removeItem("id");
                localStorage.removeItem("username");
                localStorage.removeItem("user");
              }}
            >
              Logout
            </button>
          </div>
        </div>
      );
    }
  }
}
export default Login;
