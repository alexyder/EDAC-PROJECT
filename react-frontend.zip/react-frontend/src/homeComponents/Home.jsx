import React from "react";
import MyNavbar from "../components/anshul/MyNavbar";

import Notification from "../homeComponents/Notification";
import Login from "../homeComponents/Login";
import Gallery from "../components/arun/Gallery";

import "./home.css";
import CurrentDate from "../components/anshul/CurrentDate";
import HostelCanteen from "../components/anshul/HostelCanteen";

class Home extends React.Component {
  render() {
    return (
      <div>
        <MyNavbar />
        <br />
        <br />
        <div className="containerhome">
          <div className="col2">
            <Gallery />
          </div>
          <div className="col2">
            <Notification />
          </div>
          <div className="col2">
            <Login />
            <br />
            <br />
            <CurrentDate />
            <br />
            <HostelCanteen />
          </div>
        </div>
      </div>
    );
  }
}

export default Home;
