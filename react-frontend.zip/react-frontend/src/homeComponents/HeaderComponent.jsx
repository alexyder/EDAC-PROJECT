import React, { Component } from "react";

const imglogo = (
  <img
    style={{ width: "50px", height: "50px" }}
    src="https://www.fresherslive.com/assets-images/company-logo/centre-for-development-of-advanced-computing-mumbai-logo.png"
    alt="logo"
    className="img-fluid"
  ></img>
);

class HeaderComponent extends Component {
  render() {
    return (
      <div>
        <header>
          <nav className="Myheader">
            <div className="navbar-brand">
              {imglogo} CENTRE FOR DEVELOPEMENT OF ADVANCED COMPUTING ,
              BANGALORE 👨‍🎓
            </div>
          </nav>
        </header>
      </div>
    );
  }
}

export default HeaderComponent;
