import React, { Component } from "react";

export default class DashHeader extends Component {
  render() {
    return (
      <div
        className="card , container"
        style={{ textAlign: "center", backgroundColor: "lightyellow" }}
      >
        <h4>Welcome To DashBoard 🙂</h4>
      </div>
    );
  }
}
