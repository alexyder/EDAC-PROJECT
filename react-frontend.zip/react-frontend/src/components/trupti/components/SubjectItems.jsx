export const SubjectItems = [
  {
    title: 'EDAC',
    path: '/',
    cName: 'dropdown-link'
  },
  {
    title: 'DBDA',
    path: '/',
    cName: 'dropdown-link'
  },
  {
    title: 'AI',
    path: '/',
    cName: 'dropdown-link'
  },
];


