import React from 'react';

export default function Subject() {
  return (
    <>
      <h1 className='subject'>Subject</h1>
    </>
  );
}
