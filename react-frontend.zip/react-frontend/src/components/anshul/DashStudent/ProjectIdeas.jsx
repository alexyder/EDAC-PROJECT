import React, { Component } from "react";

export default class ProjectIdeas extends Component {
  render() {
    return (
      <div>
        <div className="container">
          <div className="alert alert-success" style={{ textAlign: "center" }}>
            <h4>Project Details</h4>
          </div>
          <br />

          <h4>Guidelines to be followed:</h4>
          <hr />
          <ol>
            <li>
              Students should carry out the Project work in groups of 4-5
              students
            </li>
            <li>
              Students should submit their choice of project as per the Project
              Selection Form
            </li>
            <li>
              Each project proposal will be evaluated for feasibility before the
              project is finally allotted to students.
            </li>
          </ol>
          <br />
          <br />
          <div>
            <h4>Schedules to be followed for project</h4>
            <hr />
            <br />
            <div style={{ marginleft: "60px" }}>
              <table className="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>Sr No</th>
                    <th>Review Stages</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>1</td>
                    <td>Announcement of the Project module</td>
                  </tr>
                  <tr>
                    <td>2</td>
                    <td>Students to submit choice of project</td>
                  </tr>
                  <tr>
                    <td>3</td>
                    <td>Allocation of project / allocation of Project Guide</td>
                  </tr>
                  <tr>
                    <td>4</td>
                    <td>SRS and Design document review</td>
                  </tr>
                  <tr>
                    <td>5</td>
                    <td>Coding to Start</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          <br />
          <div>
            <h4>Documentation</h4>
            <hr />
            <br />
            <ul>
              <li>
                The basic SDLC consisting of various stages are mentioned that
                has to be followed
              </li>
              <li> Guidelines for SPMP </li>
              <li>Guidelines for coding</li>
              <ol>
                <li> Naming conventions should be followed</li>
                <li>
                  Proper indentation at appropriate locations should be
                  followed.
                </li>
                <li>
                  Comments should be relevant, adequate and self-explanatory
                </li>
                <li>
                  Information about the author and the module should be
                  adequately described at the beginning of the programme
                </li>

                <li>
                  All variables used in the programme should be explicitly
                  declared before Using the variables
                </li>

                <li>
                  Linking of function definitions and functional declarations
                  should be properly done
                </li>
              </ol>
              <li>Guidelines for Project closure report</li>
            </ul>
          </div>
          <br />
          <div>
            <h4>Project evaluation</h4>
            <hr />
            <br />
            <ul>
              <li>
                The Evaluation of the Projects will be based on the following
                parameters:
              </li>
              <li>Level of difficulty of the project</li>
              <li>Requirement elicitation and analysis</li>
              <li>Use of Quality Assurance practices </li>
              <li>Design document</li>
              <li>Adherence to Software engineering principles</li>
              <li>Test plan and software metrics</li>
              <li> Aesthetic qualities</li>
              <li>Conformance to project plan</li>
              <li>Reusability</li>
            </ul>
          </div>
          <br />
          <div>
            <h4>Sample Project Ideas:</h4>
            <hr />
            <br />
            <ul>
              <li> Virtual Sand Model</li>
              <li>Access And Control of a Remote PC</li>
              <li>LAN Monitor</li>
              <li>Online hotel Booking System</li>
              <li>Online Sales Reporting Plugin</li>
              <li>Document Management System</li>
              <li>Online Application form for CDAC</li>
              <li>Project Management System</li>
              <li>E-mail Filter</li>
              <li>Interactive Course Scheduler</li>
              <li>Bank Loan System</li>
              <li>Task Management</li>
              <li>Implementation of CMM’s Time Sheet Module</li>
              <li>Integrated Development Environment for Java</li>
              <li>RACD (Remote Access to Clinical Data)</li>
              <li>Simulation of 8085 Microprocessor</li>
              <li>Bank Transaction System</li>
              <li>Inventory Management System</li>
              <li>Development of a Portal</li>
              <li>Intranet Emailing System</li>
              <li>Vehicle Servicing Platform</li>
              <li>Document Tracking System</li>
              <li>Front Office-Cyber University System</li>
              <li>Online Shopping</li>
              <li>Website for Development of Online E-banking Facilities</li>
              <li>Chat application using RMI, servelet and applet</li>
              <li>Payroll Processing System</li>
              <li>Employees Records Management System</li>
              <li>Banking System: Fixed Deposit Management System</li>
              <li>
                Online Placement Agency- useful for both jobseekers and job
                providers
              </li>
              <li>Online Examination</li>
              <li>Horoscope</li>
              <li>Student Management System</li>
              <li>Employee Management system</li>
              <li>Inventory Management System</li>
              <li>Blood donation system</li>
              <li>Book Store Management System</li>
              <li>Payroll Management System</li>
            </ul>
          </div>
        </div>
      </div>
    );
  }
}
