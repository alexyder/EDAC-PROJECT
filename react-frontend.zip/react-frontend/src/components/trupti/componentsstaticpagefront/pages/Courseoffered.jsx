import React from 'react';
import '../../App.css';

export default function Courseoffered() {
  return <h1 className='courseoffered'>add Courses </h1>;
}
