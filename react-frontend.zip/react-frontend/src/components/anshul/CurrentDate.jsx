import React, { Component } from "react";

class CurrentDate extends Component {
  constructor(props) {
    super(props);
    this.state = {
      x: Date().toLocaleString(),
    };
  }

  updateMyTime() {
    this.setState({ x: Date().toLocaleString() });
  }

  componentWillMount() {
    setInterval(() => this.updateMyTime(), 1000);
  }

  render() {
    return (
      <div style={{ width: "100%" }} className="alert alert-success , card">
        <div style={{ padding: "25px" }}>
          <h6 style={{ textAlign: "center" }}>{this.state.x}</h6>
        </div>
      </div>
    );
  }
}

export default CurrentDate;
