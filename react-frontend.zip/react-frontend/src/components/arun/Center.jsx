import React from "react";
import { Link } from "react-router-dom";

const cntr = (
  <div>
    <h1>C-DAC Center List</h1>
    <ul>
      <Link to="/one1">
        <li>Bangalore</li>
      </Link>
      <br />
      <Link to="/Two2">
        <li>Chennai</li>
      </Link>
      <br />
      <Link to="/Three3">
        <li>Kolkata</li>
      </Link>
      <br />
      <Link to="/Four4">
        <li>Mohali</li>
      </Link>
      <br />
      <Link to="/Five5">
        <li>Pune</li>
      </Link>
      <br />
      <Link to="/Six6">
        <li>Thiruvanthapuram</li>
      </Link>
      <br />
      <Link to="/Seven7">
        <li>Delhi</li>
      </Link>
      <br />
      <Link to="/Eight8">
        <li>Hyderabad</li>
      </Link>
      <br />
      <Link to="/Nine9">
        <li>Mumbai</li>
      </Link>
      <br />
      <Link to="/Ten10">
        <li>Noida</li>
      </Link>
    </ul>
  </div>
);

function Center() {
  return cntr;
}

function one1() {
  return (
    <div>
      <p>
        <h2> About Centre:</h2>
        BengaluruC-DAC, Bengaluru centre, is the 2nd of C DAC centres to be
        established in 1989 to carry-out research and deliver solutions and
        products in the area of System Software for PARAM series of super
        computers of C-DAC. PARAM Padma, housed at C-DAC's Terascale
        Supercomputing Facility (CTSF) is a result of its third mission project
        in High Performance Computing Technologies. The centre is highly
        acclaimed as a centre for excellence in the thematic areas of High
        Performance and Grid Computing, Cyber Security and Cyber Forensic,
        Professional Electronics, FOSS and Software Technologies, Language and
        Heritage Computing and Training
        <br />
        <img src="https://www.cdac.in/index.aspx?id=img_bengaluru"></img>
        <h3>Mission</h3>
        Deliver cutting edge computing technologies Continue to maintain
        strengths in System Software Development Indigenously develop generic
        automation technologies Cater to the automation of everyday objects and
        activities Preserve and propagate the rich Indian Heritage Impart
        quality training in high-end technologies
        <h3>Main Objectives of C-DAC Bengaluru are:</h3>
        Enhancing India's role as a leader in Software Engineering and Allied
        Disciplines. To Carry out R & D in Software-intensive Systems and
        Technologies. To provide training & education in Software Engineering.
      </p>
    </div>
  );
}

function Two2() {
  return (
    <div>
      <p>
        <h1>C-DAC Chennai</h1>
        C-DAC established its centre at Chennai in 2002, to work as a Research &
        Development centre encompassing the latest technologies and also to
        provide postgraduate level training in hardware and software
        technologies, towards its allegiance to build a technically advanced
        nation. Working on strengthening national technological capabilities in
        the area of Free and Open Source Software context of global developments
        with respect to this, centre represents a unique facet working in close
        junction with DeitY to realize nation's policy and pragmatic
        interventions and initiatives in Information Technology. As a National
        Resource centre for Free and Open Source Software (NRCFOSS) is setup
        with the twin roles of bridging the digital divide as well as
        strengthening the Indian Software industry. The centre has contributed
        to the growth of FOSS in India through Research & Development, Human
        Resource Development, Networking & Entrepreneurship development, as well
        as, serve as the reference point for all FOSS related activities in the
        country. Bharat Operating System Solutions (BOSS) GNU/Linux distribution
        developed by C-DAC for enhancing the use of Free/ Open Source Software
        throughout India. The accessibility of BOSS Linux will have a
        constructive impact on the digital divide in India as more people can
        now have access to software in their local language to use the Internet
        and other information and communications technology (ICT) facilities.
        The other areas focuses are Software as Service (SaaS), Ubiquitous
        Computing, Cloud Computing and Education and Training.
        <img src="https://www.cdac.in/index.aspx?id=aboutus_os"></img>
        <h3>Secured Operating System</h3>
        It is mainly created for the clients in defence sector. The defence
        environment always requires an operating system which is free from
        intrusion and cyber attacks. OS security refers to specific measures
        that are used to protect the OS from threats, viruses, worms, malware
        and from cyber attacks. OS security encompasses all preventive-control
        techniques, which safeguards the data in the computer from being edited
        or deleted. It encompasses many different techniques and methods which
        ensure safety from threats and attacks. It allows different applications
        and programs to perform required tasks and stop unauthorized
        interference. The security of the operating system is ensured by
        providing only the required privileges to the user, regularly applying
        security patches and updating antivirus database.
      </p>
    </div>
  );
}
function Three3() {
  return (
    <div>
      <p>
        <h1>C-Dac Kolkata</h1>
        About Centre:
        <img src="https://images.shiksha.com/mediadata/images/1447654806phphoIz8N.png"></img>
        <br />
        C-DAC, Kolkata formerly known as ER&DCI, Calcutta, is one of the
        constituent units of C-DAC. It is a National Centre of Excellence in
        pioneering application oriented Research, Design and Development in
        Electronics, Information Technology and associated areas. C-DAC, Kolkata
        is an ISO 9001:2008 certified R&D Centre for the Design, Development,
        Supply, Installation, Commissioning, Turnkey Implementation,
        Maintenance, Customer Support, Consultancy and Transfer of Technology of
        Products and Systems in the area of Electronics and Information
        Technology. This certification is based on the audit conducted by STQC
        (DeitY), accredited by RvA, Netherlands, facilitating international
        validity for the ISO 9001:2008 certification. The technology development
        initiatives of the Centre are focused in the areas of Agri &
        Environmental Electronics, Knowledge & Perception Engineering, Image
        Processing, Face Recognition, Software Technologies, Health Informatics,
        Speech Processing, Information Security, Language Technology, Social
        Empowerment of Masses through IT, Digitization of Heritage assets, IT
        Systems & Services and related emerging areas. In the area of
        Agro-Electronics , Electronic Nose-Tongue-Vision (ENTV) based
        applications being pursued at Kolkata. Alpha version of integrated
        Electronic nose and vision system for tea delivered to clients. The ENV
        systems provide the industries / institutes a non-invasive method for
        objective assessment tea quality, based on the new technology. Language
        Computing : Centre is working on Machine Translation system with
        Angla-Bharati approach for Bangla and Nepali and in the Speech
        recognition system, a prosody model for Bangla. Centre is also working
        on Speech Consortia. The activities of Software Technologies include
        Software Solutions for Social Welfare & Education, Data Warehousing &
        Data Mining, Web ERP Technologies & Solutions, Heritage Computing:
        Digital Preservation and Knowledge Engineering & Health Care Solution.
        Advanced Image Processing (AIP) section is engaged in research in the
        field of Image Processing and Pattern Recognition. The section also
        develops products for particularly govt. agencies. The AIP section has
        collaborations and networking with academic and industrial research
        institutes as well as different industries of India and abroad. C-DAC
        Kolkata has expertise core competencies in speech synthesis, automatic
        speech and speaker recognition and resource creation. The centre has
        developed Bengali, Nepali and Mizo text to speech synthesizers based on
        ESNOLA method. Further advancement is achieved by incorporating prosody
        into synthesizer to meet naturalness. Indo-Japan collaboration on
        Prosody modelling in TTS has been successfully carried out. C-DAC,
        Kolkata is one of the active members of DeitY-TTS Consortium. C-DAC,
        Kolkata is developing Festival based Text to Speech synthesizers both
        for Bangla and Indian English. Further building of HMM-based Speech
        Synthesis System for Bangla and Indian English is also going on. C-DAC,
        Kolkata is a member of U-STAR (Universal Speech Translation Advanced
        Research) Consortium which is currently co-ordinated by NICT, Japan. ICT
        & Services Group at C-DAC Kolkata is engaged in Research, Development
        and Engineering projects. Development of advanced ICT products &
        solutions mostly in the social applications domain is the outcome of
        these projects. The group also executes projects on advanced ICT
        services. The in-house ICT Systems Infrastructure including Computer
        Networks, Centralised Servers & Information Security System are also
        maintained, managed and regularly upgraded by this group. ICT training
        courses under "Advanced Computing Training School" (ACTS) are also
        managed by this group. All the activities of this group are aimed to use
        ICT expertise towards building e-Society of the future. While Language
        interfaces including Handwriting recognition extend the reach of ICT, we
        all now work and live in "Networked" environments which are very often
        "Mobile" and need to be e-"Secured".
      </p>
    </div>
  );
}
function Four4() {
  return (
    <div>
      <p>
        <h1>C-DAC Mohali</h1>
        About Centre:
        <img src="https://www.cdac.in/index.aspx?id=img_mohali"></img>
        <br />
        MohaliCenter for Electronics Design & Technology of India (CEDTI),
        Mohali was setup in May 1989. Primarily with the mission to train
        manpower in electronic design & technology by offering a variety of
        training programmes in diverse aspects of electronics design, product
        development, production technology, maintenance engineering, information
        technology and quality control, etc. In December 2002, CEDTI Mohali
        merged with C-DAC with a primary mandate to promote high end R&D along
        with education and training. The centre is engaged in design and
        deployment of world class IT and electronics solutions in the following
        domains: Health Informatics Multilingual Technologies Professional
        Electronics Software Technologies Cyber Forensics and Security
        Multimedia Technologies Centre continues to play a leading role in human
        resource development and training in Information Technology (IT) sector
        in the northern region. Center offers high-end courses like M.Tech in
        VLSI as well as ME in Electronic Product Design Technology (EPDT). Short
        term value added courses and diploma are designed for knowledge based
        skill development. It also offers courses for foreign participants,
        sponsored by MEA under ITEC/SCAAP programs. Centre operates from its own
        impressive building located in the ELTOP (Electronics Town of Punjab)
        Complex amidst a large number of industries, manufacturing electronic
        products relating to computers, peripherals, communication equipment and
        components, offering a great professional challenge to the faculty and
        staff of the Centre.
      </p>
    </div>
  );
}
function Five5() {
  return (
    <div>
      <p>
        <h1>C-DAC Pune</h1>
        About Centre:
        <img src="https://www.cdac.in/index.aspx?id=img_pune"></img>
        <br />
        PuneCentre for Development of Advanced Computing (C-DAC), Pune occupies
        a special place in the evolution of the organization as a premier hub
        for cutting edge R&D. Bestowed with the distinction of being the first
        C-DAC centre to be established in the country, C-DAC, Pune has been at
        the forefront of the organizations R&D initiatives and spearheading
        several national programmes of strategic importance. C-DAC, Pune is
        credited for the first indigenously developed PARAM supercomputer and
        establishing the nationâ?Ts credentials as an enabler of advanced
        technologies. While placing India on the select world map of
        supercomputing nations, C-DAC, Pune has continued to pioneer the open
        frame architecture to deliver PARAM Yuva, which was also Indiaâ?Ts
        fastest supercomputer and rated 64 among world's top supercomputers.
        C-DAC, Pune is also recognized for promoting the concept of multilingual
        computing in the country to take IT to the grassroots level by defining
        the standards for the adoption of Indian languages on computers. Since
        then, the centre has made great strides in this arena through products
        and technologies that have created a new platform for multilingual users
        in India as well as abroad. The expertise garnered through the years of
        experience has also led C-DAC, Pune to diversify its activities to other
        domains of advanced R&D namely geomatics, human-centred design &
        computing, health informatics, and education & training. This in turn
        has elevated C-DAC, Pune into the role of a mentor and an incubator of
        innovation, in the greater national interest. As part of the mandate to
        generate manpower to address the growing demand for trained manpower in
        the advanced areas of Information Technology, C-DAC, Pune established
        its Advanced Computing Training School (ACTS). Currently the centre
        offers a variety of course options including for international
        collaborations.
      </p>
    </div>
  );
}
function Six6() {
  return (
    <div>
      <p>
        <h1>C-DAC Thiruvananthapuram</h1>
        About Centre:
        <img src="https://www.cdac.in/index.aspx?id=img_tvm"></img>
        <br />
        TVMThe centre at Thiruvananthapuram has been working in application
        oriented research, design and development for various industrial and
        customer requirements. Over the years, Centre has acquired competency,
        expertise and extensive experience in the areas of Broadcast &
        Communications, Control & Instrumentation, Networking, Power
        Electronics, ASIC Design and Underwater Electronics. Apart from the
        above, centre is also having National Resource center for computing in
        Malayalam, Resource Centre for Cyber Forensics, National Mission on
        Power Electronics Technology (NaMPET), Automation Systems Technology
        Centre (ASTeC), and Intelligent Transportation System (ITS). The Centre
        has a VLSI/ASIC design center, PCB-CAD facility, DSP lab, Industrial
        design facility, Pilot production facility and a Technology information
        center. The Centre through its diversified R&D activities in the core
        areas, has gained multi-disciplinary in-house expertise and so could
        take up and successfully complete many challenging mission mode
        products/projects in the last few years. The centre also has a tradition
        of completing product development using the outputs of advanced
        technology research. Developing the electronics products and systems of
        today demand interdisciplinary knowledge such as Networking, DSP,
        Analog, Microprocessor, VLSI, Communications protocols, RF, Power and a
        host of other specialized fields, which are very difficult and costly to
        acquire and assimilate. The centre accorded prime importance to making
        such products easily productionable, testable and field maintainable,
        thereby ensuring highly reliable operation. The technology development
        initiatives are focused in the identified core areas of Electronics and
        Information Technology, with funding from various Sponsors. The outputs
        of these efforts coupled with the high-value expertise and experience
        gained are conceptualized as products, either entirely new, or with
        quantum improvements on those based on existing technology. Scores of
        technologies developed have been transferred to Technology partners for
        large-scale production. C-DAC Thiruvananthapuram is an ISO 9001:2015
        certified R&D Centre for the Design, Development, Supply, Installation,
        Commissioning, Turnkey Implementation, Maintenance, Customer Support,
        Consultancy and Transfer of Technology of Products and Systems in the
        area of Electronics and Information Technology as well as Development
        and Implementation of Educational and Training Programmes. This
        certification is based on the audit conducted by STQC (MeitY),
        accredited by National Accreditation Board for Certification Bodies
        (NABCB), India for ISO 9000 QMS.
      </p>
    </div>
  );
}
function Seven7() {
  return (
    <div>
      <p>
        <h1>C-DAC Delhi</h1>
        About Centre: Centre at Delhi was established in 1989 as a Project Cell
        for R&D in the area of Digital Signal Processing (DSP). Being in Delhi
        and near to the Department of Electronics and Information Technology
        (DeitY), the centre is involved in various coordination activities
        between DeitY and all other centers. Current focus are of the centres
        are Natural Language Processing (Language Technology), e-Governance
        application, Real Time Application, etc. International Cooperation
        Division at Delhi Centre has acquired necessary expertise, strength and
        technical resources by implementing, supervising and managing
        international co-operation projects in Ghana, Uzbekistan, Tajikistan,
        Myanmar and Tanzania. Ministry of External Affairs (MEA) has already
        appointed C-DAC as the project-implementing agency for setting up IT
        Centre in Armenia and Belarus.
      </p>
    </div>
  );
}
function Eight8() {
  return (
    <div>
      <p>
        <h1>C-DAC Hyderabad</h1>
        About Centre:
        <img src="https://www.cdac.in/index.aspx?id=img_hyd"></img>
        <br />
        HyderabadC-DAC established its Hyderabad Centre in the year 1999 to work
        in Research, Development and Training activities embracing the latest
        Hardware & Software Technologies. The centre is a Knowledge Centre with
        the components of Knowledge Creation, Knowledge Dissemination and
        Knowledge Application to grow in the areas of Research & Development,
        Training and Business respectively. The R & D areas of the centre are
        e-Security, Embedded Systems, Ubiquitous Computing, e-Learning and ICT
        for Rural Development. The centre has developed over a period of time a
        number of products and solutions and has established a number of labs in
        cutting edge technologies. In line with these R&D strengths, the centre
        also offers Post Graduate level diploma courses. Centre is also actively
        involved in organizing faculty training programs. The centre regularly
        conducts skill based training and information security awareness
        programmes. InDG portal is hosted and maintained to facilitate rural
        development through provision of relevant information, products and
        services in local languages.
      </p>
    </div>
  );
}
function Nine9() {
  return (
    <div>
      <p>
        <h1>C-DAC Mumbai</h1>
        About Centre:
        <img src="https://www.cdac.in/index.aspx?id=img_img_mumbai1"></img>
        &nbsp;&nbsp;&nbsp;&nbsp;
        <img src="https://www.cdac.in/index.aspx?id=img_img_mumbai1"></img>
        <br />
        MumbaiMumbai C-DAC Mumbai, earlier known as NCST, started operations in
        the Juhu campus in 1985. There are two campuses in Mumbai, at Juhu and
        at Kharghar. It has a rich history of cutting edge R&D in areas of
        Computer Graphics, Computer Networks, Language Translation, Educational
        Applications of AI, Resource Scheduling, etc. It was among the pioneers
        in bringing Internet to India through the ERNET project, and also in
        multi-lingual technologies. Notable achievements of the centre include:
        First virtual trade fair system developed for Common Wealth. A series of
        vehicle scheduling applications for Air India, Oil Coordination
        Committee, and Indian oil. Customs Valuation project for Indian Customs,
        Kenya and Ethiopia. National and State level e-Governance Service
        Delivery Gateway. Biometrics solutions for Fingerprint, Iris, and Face
        Recognition. A collection of virtual lab experiments for schools
        (Olabs). ILO compliant seafarer identification solution for DG Shipping.
        Providing the entire software solution for the GATE examination spanning
        from candidate registration to score report and counselling. Mobile Seva
        project routing. Currently the centre is working in areas like
        Authentication Technologies, Disaster Recovery, Microservice based
        application development, Deep Learning applications, Mobile Computing,
        Blockchain Solutions, Virtual Labs, Educational games, Robotics,
        Accessibility, Online Assessment, etc. The Centre runs the PG-DAC
        6-month diploma programmes at both the campuses, with excellent
        placement records so far.
      </p>
    </div>
  );
}
function Ten10() {
  return (
    <div>
      <p>
        About Centre:
        <img src="https://www.cdac.in/index.aspx?id=img_noida"></img>
        <br />
        NoidaCentre at Noida formerly known as ER&DCI, Noida - is a constituent
        unit of C-DAC. It is a multi-campus center with two campuses (R&D and
        Academic) separated by a distance of about 100 meters. The current
        employee strength is around 400, of which more than 60% is engineers.
        From its very inception in 1994, the center has been working in
        application oriented design and development for various customer
        requirements. During these years, it has acquired competency, expertise
        and extensive experience in the areas of Health Informatics, Embedded
        Systems, Language Computing and e-Governance domains. These form the
        four verticals of its R&D wing. The academic wing focuses on generation
        of quality manpower in advanced software areas. It is organized as four
        schools –viz.- School of IT (SoIT), School of Electronics (SoE), School
        of Management (SoM) and Finishing School (FS). SoIT provides MCA and
        M.Tech courses in Computer Science and Information Technology. SOE
        provides M.Tech course in VLSI Design and a number of postgraduate
        diploma programs in wireless, embedded systems, and hardware design. SoM
        provides MBA course in Software Enterprise Management. These are
        affiliated to GGSIP University in New Delhi. The Finishing School offers
        various postgraduate diploma courses in many advanced topics. Centre
        stresses on synergy between education, research, and product
        development. It accords prime importance to reliability and
        maintainability of its systems in field. The technology development
        initiatives of the Centre are highly focused in the above four areas and
        are obtained predominantly with funding from the various Ministries and
        Departments of Government of India, State Governments and other
        agencies.
      </p>
    </div>
  );
}

export { one1, Two2, Three3, Four4, Five5, Six6, Seven7, Eight8, Nine9, Ten10 };
export default Center;
