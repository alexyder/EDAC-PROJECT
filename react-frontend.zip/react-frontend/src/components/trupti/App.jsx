import React from 'react';
import Navbar from './components/Navbar';
import './App.css';
import Home from './components/pages/Home';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import Course from './components/pages/Course';
import Subject from './components/pages/Subject';
import CourseMaterial from './components/pages/CourseMaterial';
import Assignments from './components/pages/Assignments';
import Notifications from './components/pages/Notifications';
import Placement from './components/pages/Placement';
import Project from './components/pages/Project';
import Queries from './components/pages/Queries';
import Exams from './components/pages/Exams';
import Results from './components/pages/Results';
import Logout from './components/pages/Logout';

function App() {
  return (
    <Router>
      <Navbar />
      <Switch>
        <Route path='/' exact component={Home} />
        <Route path='/course' component={Course} />
        <Route path='/subject' component={Subject} />
        <Route path='/course material' component={CourseMaterial} />
        <Route path='/assignment' component={Assignments} />
        <Route path='/queries' component={Queries} />
        <Route path='/project' component={Project} />
        <Route path='/placement' component={Placement} />
        <Route path='/notifications' component={Notifications} />
        <Route path='/exams' component={Exams} />
        <Route path='/results' component={Results} />
        <Route path='/logout' component={Logout} />
      </Switch>
    </Router>
  );
}

export default App;
