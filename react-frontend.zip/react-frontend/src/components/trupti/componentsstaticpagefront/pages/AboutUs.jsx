import React from 'react';
import '../../App.css';

export default function AboutUs() {
  return <h1 className='aboutus'>add about us here</h1>;
}
