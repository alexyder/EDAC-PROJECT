import React, { Component } from "react";
import MyNavbarTeacher from "../MyNavbarTeacher";
import { Route, Switch } from "react-router-dom";
import PubNoti from "./PublicNotifications";
import Projects from "./Projects";
import ViewStudents from "./ViewStudents";
import CourseNotifications from "./CourseNotifications";
import CourseMaterial from "./CourseMaterial";
import Queries from "./Queries";
import Assignments from "./Assignments";
import DashHeader from "./DashHeader";

class DashTeacher extends Component {
  render() {
    return (
      <div>
        <MyNavbarTeacher />

        <div style={{ paddingLeft: "10px" }}>
          <h4>
            <br />
            Welcome , {localStorage.getItem("username")}
            <br />
            <div>
              <h6> ID - {localStorage.getItem("id")}</h6>
            </div>
            <hr />
          </h4>
          <Switch>
            <Route path="/dashboard" exact component={DashHeader}></Route>
            <Route
              path="/dashboard/publicnotification"
              component={PubNoti}
            ></Route>
            <Route path="/dashboard/projects" component={Projects}></Route>

            <Route
              path="/dashboard/viewstudents"
              component={ViewStudents}
            ></Route>
            <Route
              path="/dashboard/coursenotifications"
              component={CourseNotifications}
            ></Route>
            <Route
              path="/dashboard/coursematerial"
              component={CourseMaterial}
            ></Route>
            <Route path="/dashboard/replyqueries" component={Queries}></Route>
            <Route
              path="/dashboard/assignments"
              component={Assignments}
            ></Route>
          </Switch>
        </div>
      </div>
    );
  }
}

export default DashTeacher;
