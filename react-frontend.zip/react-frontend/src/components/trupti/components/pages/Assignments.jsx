import React from 'react';

export default function Assignments() {
  return (
    <>
      <h1 className='assignment'>upload assignments here</h1>
    </>
  );
}
