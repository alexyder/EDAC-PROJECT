import React, { Component } from "react";
import MyNavbar from "../anshul/MyNavbar";
import "./avinash.css";
import CollegeCard from "./CollegeCards";

class Colleges extends Component {
  render() {
    return (
      <div>
        <MyNavbar />
        <div className="col-container">
          <div className="col">
            <CollegeCard
              img="https://media.istockphoto.com/vectors/bangalore-skyline-with-color-buildings-blue-sky-and-reflections-vector-id624102166?k=6&m=624102166&s=612x612&w=0&h=BDVp3OUXFdGIHH4UzHRfRZNBTR9eOYPjJc7w6gSTuzQ="
              region="Bangalore"
              clg={
                <div>
                  <li>Knowledge Park</li>
                  <li>E-City</li>
                </div>
              }
            />
            <br />
            <br />
            <CollegeCard
              img="https://us.123rf.com/450wm/sezgen/sezgen1606/sezgen160600289/57898500-stock-vector-chennai-city-water-color-panoramic-vector-illustration.jpg?ver=6"
              region="Chennai"
              clg={<li> C-DAC , Chennai</li>}
            />
            <br />
            <br />
            <CollegeCard
              img="https://previews.123rf.com/images/booblgum/booblgum1707/booblgum170700093/81572714-kochi-skyline-with-color-buildings-blue-sky-and-reflections-vector-illustration-business-travel-and-.jpg"
              region="Kochi"
              clg={<li> C-DAC, KOCHI</li>}
            />

            <br />
            <br />
            <CollegeCard
              img="https://us.123rf.com/450wm/booblgum/booblgum1808/booblgum180800246/111550985-stock-vector-patna-india-city-skyline-with-color-buildings-and-blue-sky-vector-illustration-business-travel-and-t.jpg?ver=6"
              region="Patna"
              clg={
                <div>
                  <li> C-DAC, PATNA</li>
                  <li> Astric - COE</li>
                  <li> Career Foresight</li>
                </div>
              }
            />
          </div>

          <div className="col">
            <CollegeCard
              img="https://static.vecteezy.com/system/resources/previews/000/126/281/original/mumbai-landmarks-vector.jpg"
              region="Mumbai"
              clg={
                <div>
                  <li> C-DAC, JUHU</li>
                  <li> C-DAC, KHARGHAR</li>
                  <li> AIT (YCP), Nariman Point</li>
                  <li> MET - IIT, Bandra</li>
                  <li> USM’s Shriram Mantri VITA, Juhu</li>
                </div>
              }
            />

            <br />
            <br />
            <CollegeCard
              img="https://thumbs.dreamstime.com/t/jaipur-skyline-color-landmarks-blue-sky-vector-illustration-business-travel-tourism-concept-historic-buildings-74118414.jpg"
              region="Jaipur"
              clg={
                <div>
                  <li>Netcom , Jaipur</li>
                </div>
              }
            />
            <br />
            <br />
            <CollegeCard
              img="https://media.istockphoto.com/vectors/outline-hyderabad-india-city-skyline-with-historical-buildings-and-vector-id1134157312?k=6&m=1134157312&s=612x612&w=0&h=VTl7dpNF4yU0jFsFlHx2k7V9z6gjWZ1LYOdfcZ6DUwQ="
              region="Hyderabad"
              clg={<li>C-DAC , HYDERABAD</li>}
            />
            <br />
            <br />
            <CollegeCard
              img="https://thumbs.dreamstime.com/t/kolkata-skyline-gray-landmarks-blue-sky-vector-illustration-business-travel-tourism-concept-historic-buildings-70685331.jpg"
              region="Kolkata"
              clg={<li> C-DAC, KOLKATA</li>}
            />
          </div>
          <div className="col">
            <CollegeCard
              img="https://previews.123rf.com/images/booblgum/booblgum1705/booblgum170500290/78610903-pune-skyline-with-color-buildings-blue-sky-and-reflections-vector-illustration-business-travel-and-t.jpg"
              region="Pune"
              clg={
                <div>
                  <li> Karad</li>
                  <li> C-DAC , Acts</li>
                  <li> IACSD, Akurdi </li>
                  <li> IET, Shivajinagar</li>
                  <li> Infoway, Kothrud </li>
                  <li> Know-IT, Deccan</li>
                  <li> Sunbeam, Hinjewadi </li>
                </div>
              }
            />
            <br />
            <br />
            <CollegeCard
              img="https://i.pinimg.com/originals/f7/3f/f3/f73ff32711064be9c5094531f108d73f.jpg"
              region="Delhi"
              clg={
                <div>
                  <li> Bytes Softech</li>
                  <li> C-DAC, Noida</li>
                </div>
              }
            />
            <br />
            <br />
            <CollegeCard
              img="https://media.istockphoto.com/vectors/indore-india-city-skyline-with-gray-buildings-and-blue-sky-vector-id1214397757?k=6&m=1214397757&s=612x612&w=0&h=CJunU5lGlZqZ_pKsNK4VVFgr-AKok-JymJlskbSo76Q="
              region="Indore"
              clg={<li>Orlando Academy</li>}
            />
            <br />
            <br />
            <CollegeCard
              img="https://thumbs.dreamstime.com/b/thiruvananthapuram-skyline-kerala-india-vector-thiruvananthapuram-skyline-kerala-india-illustration-represents-city-174638756.jpg"
              region="Thiruvananthapuram"
              clg={<li> C-DAC, Thiruvananthapuram</li>}
            />
          </div>
        </div>
      </div>
    );
  }
}

export default Colleges;
