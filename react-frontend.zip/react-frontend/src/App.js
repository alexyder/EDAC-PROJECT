import React from "react";

import "./App.css";
import { Route, Switch } from "react-router-dom";

import AboutUs from "./components/anshul/AboutUs";
import DashBoard from "./components/anshul/DashBoard";
import Colleges from "./components/avinash/Colleges";
import HnC from "./components/avinash/HnC";
import Home from "./homeComponents/Home";
import HeaderComponent from "./homeComponents/HeaderComponent";
import FooterComponent from "./homeComponents/FooterComponent";
import Coffered from "./components/trupti/courses_offered/Coffered";

function App() {
  return (
    <div
      style={{
        backgroundColor: "PapayaWhip",
      }}
    >
      <HeaderComponent />
      <Switch>
        <Route path="/" exact component={Home}></Route>
        <Route path="/home" component={Home}></Route>
        <Route path="/aboutus" component={AboutUs}></Route>
        <Route path="/dashboard" component={DashBoard}></Route>
        <Route path="/hostelandcanteen" component={HnC}></Route>
        <Route path="/colleges" component={Colleges}></Route>
        <Route path="/coursesoffered" component={Coffered}></Route>
      </Switch>

      <FooterComponent />
    </div>
  );
}

export default App;
