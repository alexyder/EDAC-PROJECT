import React, { Component } from "react";

class AiPage extends Component {
  render() {
    return (
      <div className="Mymargin" style={{ background: "rgba(0,0,0, 0.0)" }}>
        <h4 className="alert alert-secondary" style={{ textAlign: "center" }}>
          PG Diploma In Advanced Computing (PG-AI)
        </h4>
        <hr />
        <h5>Course Focus</h5>
        <p>
          The objective of the PG-DAI course is to present in-depth knowledge
          and applications in Artificial Intelligence using tools and case
          studies. Upon completion of this course, participants will be
          empowered to use computational techniques in the area of Artificial
          Intelligence, Natural Language Processing, Machine Learning and Deep
          Learning based applications.
        </p>
        <br />
        <hr />

        <h5>Course Content </h5>
        <p>
          <ul>
            <li>Fundamentals of Artificial Intelligence </li>
            <li> Mathematics for Artificial Intelligence</li>
            <li>Advanced Programming using Python</li>
            <li>Data Analytics</li>
            <li>Practical Machine Learning</li>
            <li>Reinforcement Learning </li>
            <li> Deep Neural Networks</li>
            <li>Natural Language Processing & Computer Vision</li>
            <li>AI Compute Platforms, Applications & Trends</li>
            <li> Effective Communication </li>
            <li>Aptitude & General English </li>
            <li>Project </li>
          </ul>
        </p>
      </div>
    );
  }
}

export default AiPage;
