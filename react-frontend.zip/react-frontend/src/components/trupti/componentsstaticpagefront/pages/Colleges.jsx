import React from 'react';

export default function Colleges() {
  return (
    <>
      <h1 className='colleges'>add college page here</h1>
    </>
  );
}
