import React, { Component } from "react";
import { Link } from "react-router-dom";

class MyNavbar extends Component {
  updatecourse(e) {
    localStorage.setItem("coffered", e.target.value);
    console.log(localStorage.getItem("coffered"));
  }

  render() {
    return (
      <div className="btn-group btn-block" role="group" aria-label="">
        <Link className="btn btn-info" to="/" style={{ borderRadius: "0px" }}>
          Home
        </Link>
        <Link
          className="btn btn-info"
          to="/aboutus"
          style={{ borderRadius: "0px" }}
        >
          About Us
        </Link>
        <Link
          to="/coursesoffered/DAC"
          className="btn btn-info"
          style={{ borderRadius: "0px" }}
          onChange={this.updatecourse}
        >
          Courses Offered
        </Link>
        <Link
          className="btn btn-info"
          to="/colleges"
          style={{ borderRadius: "0px" }}
        >
          CDAC Colleges
        </Link>
      </div>
    );
  }
}

export default MyNavbar;
