import React, { useContext } from "react";
import Z, { Fname } from "./Context2";

// const Course = React.createContext();
// const checking = (event) => {
//   <Course.Provider value={event.target.value}></Course.Provider>;
// };

function TestuseContext() {
  //   const x = useContext(Fname);
  const x = useContext(Fname);
  return (
    <div>
      <Z />
      <h3>my full name is {x}</h3>
    </div>
  );
}
export default TestuseContext;
