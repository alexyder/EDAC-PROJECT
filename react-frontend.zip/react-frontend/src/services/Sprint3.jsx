import axios from "axios";

const BASE_URL = "http://localhost:7777";

class Sprint3 {
  upload(file, course) {
    let formData = new FormData();
    formData.append("file", file);

    return axios.post(BASE_URL + "/upload/" + course, formData, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });
  }

  getFilesForTeacher() {
    return axios.get(BASE_URL + "/getallfilesforteacher");
  }

  getFilesForStudent(course) {
    return axios.get(BASE_URL + "/getallfilesforstudent/" + course);
  }

  downloadFile(fileid) {
    return axios.get(BASE_URL + "/downloadfile/" + fileid, {
      responseType: "blob",
    });
  }
}

export default new Sprint3();
